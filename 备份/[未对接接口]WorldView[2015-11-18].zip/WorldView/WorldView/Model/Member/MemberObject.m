//
//  MemberObject.m
//  WorldView
//
//  Created by WorldView on 15/11/16.
//  Copyright © 2015年 XZJ. All rights reserved.
//

#import "MemberObject.h"

@implementation MemberObject
@synthesize xDelegate, memberAccount, memberPhone, memberPhoto,memberSex,memberPassword;
- (id)init
{
    self = [super init];
    if(self){
    }
    return self;
}

#pragma mark 发送验证码
- (void)sendCode
{
    requestType = kSendCode_Request;
    [asyncRequestData startAsyncRequestData_POST: [applicationClass applicationInterfaceParamNameAndValue: [NSDictionary dictionaryWithObjectsAndKeys: SENDCODE_METHOD_ID, @"methodId", memberAccount, @"account", nil]] param: nil showIndicator: YES];
}

#pragma mark 验证验证码
- (void)validateCode:(NSString *)code
{
    requestType = kValidateCode_Request;
    [asyncRequestData startAsyncRequestData_POST: [applicationClass applicationInterfaceParamNameAndValue: [NSDictionary dictionaryWithObjectsAndKeys: VALIDATECODE_METHOD_ID, @"methodId", memberAccount, @"account",code, @"code", nil]] param: nil showIndicator: YES];
}

#pragma mark 注册接口
- (void)register
{
    requestType = kRegister_Request;
    [asyncRequestData startAsyncRequestData_POST: [applicationClass applicationInterfaceParamNameAndValue: [NSDictionary dictionaryWithObjectsAndKeys: REGISTER_METHOD_ID, @"methodId", memberAccount, @"account", memberPassword, @"password", nil]] param: nil showIndicator: YES];
}

#pragma mark 登录接口
- (void)loginIn
{
    requestType = kLogin_Request;
    [asyncRequestData startAsyncRequestData_POST: [applicationClass applicationInterfaceParamNameAndValue: [NSDictionary dictionaryWithObjectsAndKeys: LOGIN_METHOD_ID, @"methodId", memberAccount, @"account", memberPassword, @"password", nil]] param: nil showIndicator: YES];
}

#pragma mark 重置密码
- (void)resetPassword
{
    requestType = kResetPassword_Rques;
    [asyncRequestData startAsyncRequestData_POST: [applicationClass applicationInterfaceParamNameAndValue: [NSDictionary dictionaryWithObjectsAndKeys: RESETPASSWORD_METHOD_ID, @"methodId", memberAccount, @"account", memberPassword, @"password", nil]] param: nil showIndicator: YES];
}

#pragma mark -
#pragma mark XZJ_AsyncRequestData
- (void)XZJ_AsyncRequestDataReceiveData:(NSDictionary *)responseDictionary
{
    NSLog(@"%@",responseDictionary);
    NSLog(@"%@",[responseDictionary objectForKey: @"msg"]);
    switch (requestType) {
        case 0:
        {
            //发送验证码
            if([xDelegate respondsToSelector: @selector(MemberObject_DidSendCodeSuccess:)]){
                BOOL success = [[responseDictionary objectForKey: @"code"] integerValue] == INTERFACE_SUCEESS_RETURN_CODE ? YES : NO;
                [xDelegate MemberObject_DidSendCodeSuccess: success];
            }
            break;
        }
        case 1:
        {
            ///验证验证码
            if([xDelegate respondsToSelector: @selector(MemberObject_ValidateCode:)]){
                BOOL isPass = [[responseDictionary objectForKey: @"code"] integerValue] == INTERFACE_SUCEESS_RETURN_CODE ? YES : NO;
                [xDelegate MemberObject_ValidateCode: isPass];
            }
            break;
        }
        case 2:
        {
            //注册
            if([xDelegate respondsToSelector: @selector(MemberObject_DidRegisterSuccess:)]){
                BOOL isPass = [[responseDictionary objectForKey: @"code"] integerValue] == INTERFACE_SUCEESS_RETURN_CODE ? YES : NO;
                [xDelegate MemberObject_DidRegisterSuccess: isPass];
            }
            break;
        }
        case 3:
        {
            //登录
            if([xDelegate respondsToSelector: @selector(MemberObject_DidLoginInSuceess: data:)]){
                BOOL success = [[responseDictionary objectForKey: @"code"] integerValue] == INTERFACE_SUCEESS_RETURN_CODE ? YES : NO;
                [xDelegate MemberObject_DidLoginInSuceess: success data: [responseDictionary objectForKey: @"data"]];
            }
            break;
        }
        case 4:
        {
            //重置密码
            if([xDelegate respondsToSelector: @selector(MemberObject_DidResetPasswordSuccess:)]){
                BOOL success = [[responseDictionary objectForKey: @"code"] integerValue] == INTERFACE_SUCEESS_RETURN_CODE ? YES : NO;
                [xDelegate MemberObject_DidResetPasswordSuccess: success];
            }
            break;
        }
        default:
            break;
    }
}
@end
