//
//  MemberObject.h
//  WorldView
//
//  Created by WorldView on 15/11/16.
//  Copyright © 2015年 XZJ. All rights reserved.
//
#define REGISTER_METHOD_ID @"m0003"
#define LOGIN_METHOD_ID @"m0004"
#define SENDCODE_METHOD_ID @"m0014"
#define VALIDATECODE_METHOD_ID @"m0002"
#define RESETPASSWORD_METHOD_ID @"m0005"
#import <Foundation/Foundation.h>
#import "ModelObject.h"

typedef enum {
    kSendCode_Request = 0,
    kValidateCode_Request = 1,
    kRegister_Request = 2,
    kLogin_Request = 3,
    kResetPassword_Rques = 4
}RequestType;

@protocol MemberObjectDelegate <NSObject>
@optional
- (void)MemberObject_DidSendCodeSuccess:(BOOL) success;
- (void)MemberObject_ValidateCode:(BOOL) isPass;
- (void)MemberObject_DidRegisterSuccess:(BOOL) success;
- (void)MemberObject_DidLoginInSuceess:(BOOL) success data:(NSDictionary *) dictionary;
- (void)MemberObject_DidResetPasswordSuccess:(BOOL) success;
@end

@interface MemberObject : ModelObject
{
    RequestType requestType;
}
@property(nonatomic, retain)id<MemberObjectDelegate> xDelegate;//委托对象
@property(nonatomic, retain)NSString *memberAccount; //会员账号
@property(nonatomic, retain)NSString *memberPassword; //会员密码
@property(nonatomic, retain)NSString *memberPhoto; //会员头像
@property(nonatomic, retain)NSString *memberPhone; // 会员手机号码
@property(nonatomic, retain)NSString *memberSex; // 会员性别

- (void)sendCode;
- (void)validateCode:(NSString *)code;
- (void)register;
- (void)loginIn;
- (void)resetPassword;
@end
