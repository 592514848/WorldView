//
//  CountryClass.m
//  WorldView
//
//  Created by WorldView on 15/11/18.
//  Copyright © 2015年 XZJ. All rights reserved.
//

#import "CountryClass.h"

@implementation CountryClass
- (id)init
{
    self = [super init];
    if(self){
        
    }
    return self;
}
@end
