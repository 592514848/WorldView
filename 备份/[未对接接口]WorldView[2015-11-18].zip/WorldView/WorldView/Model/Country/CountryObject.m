//
//  CountryObject.m
//  WorldView
//
//  Created by WorldView on 15/11/18.
//  Copyright © 2015年 XZJ. All rights reserved.
//

#import "CountryObject.h"
@implementation CountryObject
@synthesize xDelegate;
- (id)init
{
    self = [super init];
    if(self){
        
    }
    return self;
}

#pragma mark 获取城市列表
- (void)countryList
{
    [asyncRequestData startAsyncRequestData_POST: [applicationClass applicationInterfaceParamNameAndValue: [NSDictionary dictionaryWithObjectsAndKeys: COUNTRYLIST_METHOD_ID, @"methodId", nil]] param: nil showIndicator: YES];
}

#pragma mark -
#pragma mark XZJ_AsyncRequestData
- (void)XZJ_AsyncRequestDataReceiveData:(NSDictionary *)responseDictionary
{
    NSLog(@"%@", responseDictionary);
    if([xDelegate respondsToSelector: @selector(countryObject_GetCountryList:)]){
        NSArray *tempArray = [responseDictionary objectForKey: @"data"];
        NSMutableArray *cuntryListArray = [NSMutableArray arrayWithCapacity: [tempArray count]];
        for(NSDictionary *dictionary in tempArray){
            CountryClass *country = [[CountryClass alloc] init];
            [country setCountryId: [dictionary objectForKey: @"id"]];
            [country setCountryName: [dictionary objectForKey: @"countryName"]];
            [cuntryListArray addObject: country];
        }
        [xDelegate countryObject_GetCountryList: cuntryListArray];
    }
}
@end
