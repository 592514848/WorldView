//
//  CountryObject.h
//  WorldView
//
//  Created by WorldView on 15/11/18.
//  Copyright © 2015年 XZJ. All rights reserved.
//
#define COUNTRYLIST_METHOD_ID @"m0008"
#import "ModelObject.h"
#import "CountryClass.h"

@protocol CountryObjectDelegate <NSObject>
@optional
- (void)countryObject_GetCountryList:(NSArray *) dataArray;
@end

@interface CountryObject : ModelObject
@property(nonatomic, retain)id<CountryObjectDelegate> xDelegate;//委托对象
- (void)countryList;
@end
