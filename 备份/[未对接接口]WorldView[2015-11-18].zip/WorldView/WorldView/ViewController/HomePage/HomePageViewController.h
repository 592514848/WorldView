//
//  HomePageViewController.h
//  WorldView
//
//  Created by XZJ on 10/28/15.
//  Copyright © 2015 XZJ. All rights reserved.
//

#import "BaseViewController.h"
#import "HomePageLoginView.h"
#import "HomePageNewsView.h"
#import "HomePageLocationView.h"
#import "HomePageMemberView.h"
#import "HomePageMainListView.h"
#import "XZJ_SideBarView.h"

@interface HomePageViewController : BaseViewController<HomePageLocationViewDelegate, HomePageNewsViewDelegate, HomePageMemberViewDelegate, XZJ_SideBarViewDelegate, HomePageLoginViewDelegate>
{
    XZJ_SideBarView *sideBarMainView; //侧边栏
    CGFloat siderBarBackroundAplha;
    NSTimer *timer;
    UIButton *navigationRightButton;
    UIButton *navigationLeftButton;
    BOOL isPushNextVC;
    NSIndexPath *curOperateIndexPath;
    HomePageMainListView *homePageMainView;
    HomePageMemberView *mainMemberView;
    HomePageLoginView *mainLoginView;
}
@end
