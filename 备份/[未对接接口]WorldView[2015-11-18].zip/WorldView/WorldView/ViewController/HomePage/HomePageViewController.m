//
//  HomePageViewController.m
//  WorldView
//
//  Created by XZJ on 10/28/15.
//  Copyright © 2015 XZJ. All rights reserved.
//
#define NAVIGATIONBAR_HEIGHT 44.0f
#import "HomePageViewController.h"
#import "TravelListViewController.h"
#import "PrivateMessageListViewController.h"
#import "WishListViewController.h"
#import "ReserveListViewController.h"
#import "PublishedJourneyViewController.h"
#import "PJStepOneViewController.h"
#import "MemberInfoViewController.h"
#import "LoginViewController.h"
#import "EmailRegisterNavigationController.h"
#import "PhoneRegisternavigationController.h"
#import "SettingViewController.h"
@implementation HomePageViewController
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self loadSideslipBar];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self loadMainView];
    [self loadNavigationBar];
    
    ///广告图片(测试)
    HomePageNewsView *newsView = [[HomePageNewsView alloc] initWithFrame: [[UIScreen mainScreen] bounds] buttonRect: CGRectMake(0.0f, 0.0f, NAVIGATIONBAR_HEIGHT, NAVIGATIONBAR_HEIGHT) delegate: self];
    [navigationLeftButton setHidden: YES];
    [[[UIApplication sharedApplication] keyWindow] addSubview: newsView];
}
#pragma mark -
#pragma mark 加载主视图
- (void)loadMainView
{
    homePageMainView = [[HomePageMainListView alloc] initWithFrame: CGRectMake(0.0f, 0.0f, curScreenSize.width, curScreenSize.height) dataCount: 5];
    [homePageMainView setViewControllerSender: self];
    [self.view addSubview: homePageMainView];
}

#pragma mark -
#pragma mark 加载导航栏
- (void)loadNavigationBar
{
    ////初始化导航栏
    navigationLeftButton = [[UIButton alloc] initWithFrame: CGRectMake(0.0f, 0.0f, NAVIGATIONBAR_HEIGHT, NAVIGATIONBAR_HEIGHT)];
    [navigationLeftButton setImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: @"hp_member" ofType: @"png"]] forState: UIControlStateNormal];
    [navigationLeftButton setContentMode: UIViewContentModeScaleAspectFit];
    [navigationLeftButton setImageEdgeInsets: UIEdgeInsetsMake(12.0f, 12.0f, 12.0f, 12.0f)];
    [navigationLeftButton setTag: 0];
    [navigationLeftButton addTarget: self action: @selector(BarButtonItemClick:) forControlEvents: UIControlEventTouchUpInside];
    UIBarButtonItem *barBurronItem = [[UIBarButtonItem alloc] initWithCustomView: navigationLeftButton];
    [self.navigationItem setLeftBarButtonItem: barBurronItem];
    ////
    navigationRightButton = [[UIButton alloc] initWithFrame: CGRectMake(0.0f, 0.0f, NAVIGATIONBAR_HEIGHT, NAVIGATIONBAR_HEIGHT)];
    [navigationRightButton setImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: @"hp_ball" ofType: @"png"]] forState: UIControlStateNormal];
    [navigationRightButton setContentMode: UIViewContentModeScaleAspectFit];
    [navigationRightButton setImageEdgeInsets: UIEdgeInsetsMake(12.0f, 12.0f, 12.0f, 12.0f)];
    [navigationRightButton setTag: 1];
    [navigationRightButton addTarget: self action: @selector(BarButtonItemClick:) forControlEvents: UIControlEventTouchUpInside];
    barBurronItem = [[UIBarButtonItem alloc] initWithCustomView: navigationRightButton];
    [self.navigationItem setRightBarButtonItem: barBurronItem];
    UIImageView *titleImageView = [[UIImageView alloc] initWithFrame: CGRectMake(0.0f, 12.0f, curScreenSize.width - NAVIGATIONBAR_HEIGHT, NAVIGATIONBAR_HEIGHT - 24.0f)];
    [titleImageView setImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: @"hp_logo" ofType: @"png"]]];
    [titleImageView setContentMode: UIViewContentModeScaleAspectFit];
    [self.navigationItem setTitleView: titleImageView];
}

#pragma mark 导航栏按钮点击事件
-(void)BarButtonItemClick:(UIButton *) sender
{
    switch ([sender tag]) {
        case 0:
            [sideBarMainView show];
            break;
        case 1:
        {
            [navigationRightButton setHidden: YES];
            HomePageLocationView *locationView = [[HomePageLocationView alloc] initWithFrame: [[UIScreen mainScreen] bounds] buttonRect: CGRectMake(0.0f, 0.0f, NAVIGATIONBAR_HEIGHT, NAVIGATIONBAR_HEIGHT) delegate: self];
            [[[UIApplication sharedApplication] keyWindow] addSubview: locationView];
            break;
        }
        default:
            break;
    }
}

#pragma mark -
#pragma mark 加载侧边栏
- (void)loadSideslipBar
{
    ////1.初始化侧边栏
    CGFloat sideBarWidth = curScreenSize.width - 75.0f;
    if(!sideBarMainView){
        sideBarMainView = [[XZJ_SideBarView alloc] initWithFrame: CGRectMake(0.0f, 0.0f, curScreenSize.width, [[UIScreen mainScreen] bounds].size.height) sideBarWidth: sideBarWidth];
        [sideBarMainView setXDelegate: self];
        [[[UIApplication sharedApplication] keyWindow] addSubview: sideBarMainView];
        [[[UIApplication sharedApplication] keyWindow] bringSubviewToFront: sideBarMainView];
        ////2.侧滑手势
        UIPanGestureRecognizer *panGestureRecognizer = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePanGesture:)];
        [self.view addGestureRecognizer:panGestureRecognizer];
    }
    ////初始化内容试图
    if(isLogin){
        if(!mainMemberView)
        {
            mainMemberView = [[HomePageMemberView alloc] initWithFrame: CGRectMake(0.0f, 0.0f, sideBarMainView.sideBarWidth, sideBarMainView.frame.size.height) delegate: self];
            [sideBarMainView setContentViewInSideBar: mainMemberView];
        }
        else{
            [mainLoginView setHidden: YES];
            [mainMemberView setHidden: NO];
        }
    }
    else{
        if(!mainLoginView)
        {
            ///未登录状态
            mainLoginView = [[HomePageLoginView alloc] initWithFrame: CGRectMake(0.0f, 0.0f, sideBarMainView.sideBarWidth, sideBarMainView.frame.size.height) sender: self];
            [sideBarMainView setContentViewInSideBar: mainLoginView];
        }
        else{
            [mainLoginView setHidden: NO];
            [mainMemberView setHidden: YES];
        }
    }
}

#pragma mark 处理侧滑手势
- (void)handlePanGesture:(UIPanGestureRecognizer *)recognizer
{
//    ////当手势在屏幕的1/2处时，才启动侧边栏
//    if (recognizer.state == UIGestureRecognizerStateBegan) {
//        CGPoint startPoint = [recognizer locationInView:self.view];
//        if (startPoint.x < self.view.bounds.size.width / 2.0) {
//            [sideBarMainView handlePanGestureToShow:recognizer inView: self.view];
//        }
//    }
    [sideBarMainView handlePanGestureToShow:recognizer inView: self.view];
}

#pragma mark 侧滑委托
- (void)sideBar:(XZJ_SideBarView *)sideBar willAppear:(BOOL)animated
{
//    ///调整主视图大小
//    [self.view setFrame: CGRectMake(0.0f, 0.0f, curScreenSize.height, curScreenSize.height+ 100.0f)];
//    [homePageMainView updateFrame: CGRectMake(0.0f, 0.0f, curScreenSize.width, self.view.frame.size.height)];
//    ///隐藏导航栏
//    [[UIApplication sharedApplication] setStatusBarHidden:YES withAnimation:UIStatusBarAnimationSlide];
}

- (void)sideBar:(XZJ_SideBarView *)sideBar didAppear:(BOOL)animated
{
//    ///调整主视图大小
//    [self.view setFrame: CGRectMake(0.0f, 0.0f, curScreenSize.height, curScreenSize.height)];
//    [homePageMainView updateFrame: CGRectMake(0.0f, 0.0f, curScreenSize.width, self.view.frame.size.height)];
}

- (void)sideBar:(XZJ_SideBarView *)sideBar willDisappear:(BOOL)animated
{
//    [[UIApplication sharedApplication] setStatusBarHidden:NO withAnimation:UIStatusBarAnimationSlide];
}

- (void)sideBar:(XZJ_SideBarView *)sideBar didDisappear:(BOOL)animated
{
    if(isPushNextVC){
        isPushNextVC = NO;
        switch ([curOperateIndexPath section]) {
            case 0:
            {
                switch ([curOperateIndexPath row]) {
                    case 0:
                    {
                        MemberInfoViewController *nextVC = [[MemberInfoViewController alloc] init];
                        [self.navigationController pushViewController: nextVC animated: YES];
                        break;
                    }
                    case 1:
                    {
                        PJStepOneViewController *nextVC = [[PJStepOneViewController alloc] init];
                        [self.navigationController pushViewController: nextVC animated: YES];
                        break;
                    }
                    default:
                        break;
                }
                break;
            }
            case 1:
            {
                switch ([curOperateIndexPath row]) {
                    case 0:
                    {
                        ////我的行程单
                        TravelListViewController *traveListVC = [[TravelListViewController alloc] init];
                        [self.navigationController pushViewController: traveListVC animated: YES];
                        break;
                    }
                    case 1:
                    {
                        ////我的心愿单
                        WishListViewController *wishListVC = [[WishListViewController alloc] init];
                        [self.navigationController pushViewController: wishListVC animated: YES];
                        break;
                    }
                    case 2:
                    {
                        ////私信
                        PrivateMessageListViewController *pmListVC = [[PrivateMessageListViewController alloc] init];
                        [self.navigationController pushViewController: pmListVC animated: YES];
                    }
                    default:
                        break;
                }
                break;
            }
            case 2:
            {
                ////判断是不是猎人
                switch ([curOperateIndexPath row]) {
                    case 0:
                    {
                        ///我收到的预定
                        ReserveListViewController *reserveListVC = [[ReserveListViewController alloc] init];
                        [self.navigationController pushViewController: reserveListVC animated: YES];
                        break;
                    }
                    case 1:
                    {
                        ///我发布的旅程
                        PublishedJourneyViewController *publishedListVC = [[PublishedJourneyViewController alloc] init];
                        [self.navigationController pushViewController: publishedListVC animated: YES];
                        break;
                    }
                    default:
                        break;
                }
            }
            case 3:
            {
                switch ([curOperateIndexPath row]) {
                    case 2:
                    {
                        SettingViewController *settingVC = [[SettingViewController alloc] init];
                        [self.navigationController pushViewController: settingVC animated: YES];
                        break;
                    }
                    default:
                        break;
                }
                break;
            }
            default:
                break;
        }
    }

}

#pragma mark -
#pragma mark HomePageLocationViewDelegate
- (void)homePageLocationView_DidCancelButton
{
    [navigationRightButton setHidden: NO];
}

#pragma mark -
#pragma mark HomePageNewsViewDelegate
- (void)homePageNewsView_DidCancelButton
{
    [navigationLeftButton setHidden: NO];
}

#pragma mark -
#pragma mark HomePageMemberViewDelegate
- (void)homePageMemberView_WillDisplay:indexPath
{
    curOperateIndexPath = indexPath;
    isPushNextVC = YES;
    [sideBarMainView dismiss];
}

- (void)homePageLoginView_DidClick:(NSInteger)index
{
    [sideBarMainView dismiss];
    switch(index){
        case 0:
        {
            LoginViewController *loginVC = [[LoginViewController alloc] init];
            [loginVC setXZJ_ControlMask: kMODALControlMask];
            [loginVC setTopBarTitle: @"用户登录"];
            [self presentViewController: loginVC animated: YES completion: nil];
            break;
        }
        case 1:
        {
            PhoneRegisternavigationController *registerVC = [[PhoneRegisternavigationController alloc] init];
            [self presentViewController: registerVC animated: YES completion: nil];
            break;
        }
        case 2:
        {
            EmailRegisterNavigationController *registerVC = [[EmailRegisterNavigationController alloc] init];
            [self presentViewController: registerVC animated: YES completion: nil];
            break;
        }
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
