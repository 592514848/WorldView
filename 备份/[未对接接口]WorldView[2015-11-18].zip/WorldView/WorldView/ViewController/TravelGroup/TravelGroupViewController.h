//
//  TravelGroupViewController.h
//  WorldView
//
//  Created by XZJ on 11/3/15.
//  Copyright © 2015 XZJ. All rights reserved.
//

#import "BaseViewController.h"
#import "PickerQueryView.h"
#import "WishListTableViewCell.h"

@interface TravelGroupViewController : BaseViewController<XZJ_EGOTableViewDelegate, UIScrollViewDelegate, PickerQueryViewDelegate, WishListTableViewCellDelegate>
{
    UIScrollView *mainScrollView;
    XZJ_EGOTableView *mainTableView;
    UIButton *lastSelectedButton;
    UIView *pickereView;
    BOOL isAdjustView; //是否调整视图
    NSTimer *mainTimer;
    CGPoint mainScrollVeiwPoint;
    UIButton *navigationRightButton;
    PickerQueryView *pickerQueryView;
    
    UIImageView *bgImageView;
}
@end
