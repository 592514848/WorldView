//
//  PickerQueryView.h
//  WorldView
//
//  Created by XZJ on 11/9/15.
//  Copyright © 2015 XZJ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XZJ_ApplicationClass.h"
#import "PickerQueryTableViewCell.h"
#import "HP_Locaction_TableViewCell.h"

@protocol PickerQueryViewDelegate <NSObject>
- (void)pickerQueryViewDelegate_DidCancelButton;
@end

@interface PickerQueryView : UIView<UITableViewDataSource, UITableViewDelegate, UITableViewDataSource, UITableViewDelegate>
{
    UIView *lineView;
    NSTimer *timer;
    UIView *contentView;
    UIView *cityContentVeiw;
    XZJ_ApplicationClass *applicationClass;
    id<PickerQueryViewDelegate> xDelegate;
    CGFloat cellHeight;
    PickerQueryTableViewCell *lastSelectedCell;
    UIButton *lastSequeensButton;
    CGFloat selfAlpha;
}
- (id)initWithFrame:(CGRect)frame buttonRect:(CGRect) buttonFrame delegate:(id<PickerQueryViewDelegate>) _delegate;

- (void)show;
- (void)dismiss;
@end
