//
//  EvaluationListViewController.m
//  WorldView
//
//  Created by WorldView on 15/11/16.
//  Copyright © 2015年 XZJ. All rights reserved.
//
#define CELL_HEIGHT 120.0F
#import "EvaluationListViewController.h"
#import "EvaluationTableViewCell.h"

@implementation EvaluationListViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    [self setTitle: @"评论列表"];
    [self loadMainView];
}

- (void)loadMainView
{
    UITableView *mainTableView = [[UITableView alloc] initWithFrame: CGRectMake(0.0f, 0.0f, curScreenSize.width, curScreenSize.height)];
    [mainTableView setDelegate: self];
    [mainTableView setDataSource: self];
    UIView *footerView = [[UIView alloc] init];
    [footerView setBackgroundColor: [UIColor clearColor]];
    [mainTableView setTableFooterView: footerView];
    [self.view addSubview: mainTableView];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 4;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    EvaluationTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier: @"ListCell"];
    if(!cell){
        cell = [[EvaluationTableViewCell alloc] initWithStyle: UITableViewCellStyleDefault reuseIdentifier: @"ListCell" size: CGSizeMake(tableView.frame.size.width, CELL_HEIGHT)];
    }
    [cell.photoImageView setImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: @"photo" ofType: @"jpg"]]];
    [cell.nameLabel setText: @"Liliyan 百花"];
    [cell setStarLevel: 2];
    [cell.contentLabel setText: @"非常好的体验，很用心很周到，而且住的地方也很不错，介绍也很详细..."];
    [cell.timeLabel setText: @"2015-11-12"];
    [cell setSelectionStyle: UITableViewCellSelectionStyleNone];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return CELL_HEIGHT;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
