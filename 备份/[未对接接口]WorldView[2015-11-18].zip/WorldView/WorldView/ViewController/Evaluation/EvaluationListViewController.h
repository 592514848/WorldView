//
//  EvaluationListViewController.h
//  WorldView
//
//  Created by WorldView on 15/11/16.
//  Copyright © 2015年 XZJ. All rights reserved.
//

#import "BaseViewController.h"

@interface EvaluationListViewController : BaseViewController<UITableViewDataSource, UITableViewDelegate>

@end
