//
//  MemberInfoViewController.h
//  WorldView
//
//  Created by WorldView on 15/11/14.
//  Copyright © 2015年 XZJ. All rights reserved.
//

#import "BaseViewController.h"
@interface MemberInfoViewController : BaseViewController<UITableViewDataSource, UITableViewDelegate, UITextViewDelegate, UITextFieldDelegate>
{
    id lastResponser;
    UIScrollView *mainScrollView;
    XZJ_CustomLabel *fontNumberLabel;
    NSString *textViewText;
    UIImageView *lastSelectedSexImageView;
    UIImageView *lastSelectedLanguageImageView;
}
@end
