//
//  AppointmentViewController.m
//  WorldView
//
//  Created by XZJ on 11/10/15.
//  Copyright © 2015 XZJ. All rights reserved.
//
#define BOTTOM_VIEW_HEIGHT 50.0f
#define TOP_IMAGE_HEIGHT 200.0f
#define MASK_VIEW_HEIGHT 20.0f
#define HUNTER_INFO_HEIGHT 210.0f
#define MARGIN_LEFT 15.0F
#define PHOTO_IMAGE_HEIGHT 70.0f
#define TAG_IMAGE_HEIGHT 20.0f
#define TRAVEL_VIEW_HEIGHT 400.0f
#define LINE_LABEL_WIDTH 70.0f
#define LINE_LABEL_HEIGHT 30.0f
#define CONTENT_IMAGE_HEIGHT 150.0f
#define MEETPLACE_VIEW_HEIGHT 240.0f
#define EVALUTION_VIEW_HEIGHT 380.0f
#define OTHER_VIEW_HEIGHT 320.0f
#define RECOMMON_VIEW_HEIGHT 620.0f
#define CARD_MARGIN_LEFT 20.0F
#define CARD_BOTTOM_HEIGHT 55.0F
#import "AppointmentViewController.h"
@implementation AppointmentViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self loadMainView];
    [self loadBottomView];
}

#pragma mark -
#pragma mark 加载底部视图
- (void)loadBottomView
{
    ///1.底部住视图
    UIView *bottomView = [[UIView alloc] initWithFrame: CGRectMake(0.0f, curScreenSize.height - BOTTOM_VIEW_HEIGHT, curScreenSize.width, BOTTOM_VIEW_HEIGHT)];
    [bottomView setBackgroundColor: [applicationClass methodOfTurnToUIColor: @"#ff3546"]];
    [self.view addSubview: bottomView];
    
    ///2.价格
    XZJ_CustomLabel *priceLabel = [[XZJ_CustomLabel alloc] initWithFrame: CGRectMake(40.0f, 0.0f, bottomView.frame.size.width / 2.0f - 40.0f, BOTTOM_VIEW_HEIGHT)];
    [priceLabel setTextColor: [UIColor whiteColor]];
    NSMutableAttributedString *attributteString = [[NSMutableAttributedString alloc] initWithString: @"$128/人"];
    [attributteString addAttribute: NSFontAttributeName value: [UIFont systemFontOfSize: 10.0f] range: NSMakeRange(0, 1)];
    [attributteString addAttribute: NSFontAttributeName value: [UIFont systemFontOfSize: 15.0f] range: NSMakeRange(1, 3)];
    [attributteString addAttribute: NSFontAttributeName value: [UIFont systemFontOfSize: 10.0f] range: NSMakeRange(4, 2)];
    [priceLabel setAttributedText: attributteString];
    [bottomView addSubview: priceLabel];
    
    ///3.预约按钮
    UIButton *appointButton = [[UIButton alloc] initWithFrame: CGRectMake(bottomView.frame.size.width - 120.0f, 10.0f, 80.0f, BOTTOM_VIEW_HEIGHT - 20.0f)];
    [appointButton setTitle: @"立即预约" forState: UIControlStateNormal];
    [appointButton setTitleColor: [UIColor whiteColor] forState: UIControlStateNormal];
    [appointButton.titleLabel setFont: [UIFont systemFontOfSize: 13.0f]];
    [appointButton addTarget: self action: @selector(appointButtonClick) forControlEvents: UIControlEventTouchUpInside];
    [appointButton.layer setCornerRadius: 3.0f];
    [appointButton.layer setBorderWidth: 0.5f];
    [appointButton.layer setBorderColor: [UIColor whiteColor].CGColor];
    [bottomView addSubview: appointButton];
}

#pragma mark -
#pragma mark 加载主视图
- (void)loadMainView
{
    ///1.主视图
    mainScrollView = [[UIScrollView alloc] initWithFrame: CGRectMake(0.0f, 0.0f, curScreenSize.width, curScreenSize.height - BOTTOM_VIEW_HEIGHT)];
    [mainScrollView setShowsVerticalScrollIndicator: NO];
    [mainScrollView setBackgroundColor: [applicationClass methodOfTurnToUIColor: @"#f0f0f0"]];
    [self.view addSubview: mainScrollView];
    
    ///2.顶部视图
    UIImageView *topImageView = [[UIImageView alloc] initWithFrame: CGRectMake(0.0f, 0.0f, curScreenSize.width, TOP_IMAGE_HEIGHT)];
    [topImageView setImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: @"top" ofType: @"png"]]];
    [topImageView setContentMode: UIViewContentModeScaleAspectFill];
    [topImageView.layer setMasksToBounds: YES];
    [mainScrollView addSubview: topImageView];
    
    ///3.覆盖视图
    UIView *imageMaskView = [[UIView alloc] initWithFrame: CGRectMake(0.0f, TOP_IMAGE_HEIGHT - MASK_VIEW_HEIGHT, topImageView.frame.size.width, MASK_VIEW_HEIGHT)];
    [imageMaskView setBackgroundColor: [[UIColor alloc] initWithWhite: 0.2f alpha: 0.5f]];
    [topImageView addSubview: imageMaskView];
    ///4.定位图标
    UIImageView *iconImageView = [[UIImageView alloc] initWithFrame: CGRectMake(20.0f, 5.0f, MASK_VIEW_HEIGHT, MASK_VIEW_HEIGHT - 10.0f)];
    [iconImageView setImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: @"icon_location" ofType: @"png"]]];
    [iconImageView setContentMode: UIViewContentModeScaleAspectFit];
    [imageMaskView addSubview: iconImageView];
    ///5.地点名称
    CGFloat origin_x = iconImageView.frame.size.width +iconImageView.frame.origin.x;
    XZJ_CustomLabel *locationNameLabel = [[XZJ_CustomLabel alloc] initWithFrame: CGRectMake(origin_x, 0.0f, imageMaskView.frame.size.width / 2.0f - origin_x, MASK_VIEW_HEIGHT)];
    [locationNameLabel setTextColor: [UIColor whiteColor]];
    [locationNameLabel setTextAlignment: NSTextAlignmentLeft];
    [locationNameLabel setFont: [UIFont systemFontOfSize: 10.0f]];
    [locationNameLabel setText: @"意大利，威尼斯"];
    [imageMaskView addSubview: locationNameLabel];
    ///6.人数图标
    iconImageView = [[UIImageView alloc] initWithFrame: CGRectMake(imageMaskView.frame.size.width * 2.0f / 3.0f, 5.0f, MASK_VIEW_HEIGHT, MASK_VIEW_HEIGHT - 10.0f)];
    [iconImageView setImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: @"icon_person" ofType: @"png"]]];
    [iconImageView setContentMode: UIViewContentModeScaleAspectFit];
    [imageMaskView addSubview: iconImageView];
    ///7.参加的人数
    origin_x = iconImageView.frame.size.width + iconImageView.frame.origin.x;
    XZJ_CustomLabel *joinNumberLabel = [[XZJ_CustomLabel alloc] initWithFrame: CGRectMake(origin_x, 0.0f, imageMaskView.frame.size.width - origin_x - 10.0f, MASK_VIEW_HEIGHT)];
    [joinNumberLabel setTextColor: [UIColor whiteColor]];
    [joinNumberLabel setFont: [UIFont systemFontOfSize: 10.0f]];
    [joinNumberLabel setText: @"已经有26人参与"];
    [imageMaskView addSubview: joinNumberLabel];
    
    ///////8.猎人信息展示
    CGFloat origin_y = TOP_IMAGE_HEIGHT + topImageView.frame.origin.y;
    UIView *hunterBGView = [[UIView alloc] initWithFrame: CGRectMake(0.0f, origin_y, curScreenSize.width, HUNTER_INFO_HEIGHT)];
    [hunterBGView setBackgroundColor: [UIColor whiteColor]];
    [hunterBGView.layer setShadowOpacity: 0.2f];
    [hunterBGView.layer setShadowOffset: CGSizeMake(0.0f, 3.0f)];
    [mainScrollView addSubview: hunterBGView];
    ///9.头像
    UIImageView *photoImageView = [[UIImageView alloc] initWithFrame: CGRectMake(MARGIN_LEFT, 10.0f, PHOTO_IMAGE_HEIGHT, PHOTO_IMAGE_HEIGHT)];
    [photoImageView.layer setCornerRadius: PHOTO_IMAGE_HEIGHT / 2.0f];
    [photoImageView.layer setBorderColor: [applicationClass methodOfTurnToUIColor:@"#ffcddb"].CGColor];
    [photoImageView.layer setBorderWidth: 2.0f];
    [photoImageView setContentMode: UIViewContentModeScaleAspectFill];
    [photoImageView.layer setMasksToBounds: YES];
    [photoImageView setImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: @"photo" ofType: @"jpg"]]];
    [hunterBGView addSubview: photoImageView];
    ///10.标题
    origin_x = photoImageView.frame.size.width + photoImageView.frame.origin.x+ 10.0f;
    origin_y = photoImageView.frame.origin.y;
    XZJ_CustomLabel *titleLabel = [[XZJ_CustomLabel alloc] initWithFrame: CGRectMake(origin_x, origin_y, curScreenSize.width - origin_x - MARGIN_LEFT, photoImageView.frame.size.height / 2.0f)];
    [titleLabel setTextColor: [applicationClass methodOfTurnToUIColor: @"#444444"]];
    [titleLabel setText: @"我在小船上等你，与你一起感受浪漫威尼斯"];
    [titleLabel setFont: [UIFont systemFontOfSize: 14.0f]];
    [titleLabel setLineBreakMode: NSLineBreakByTruncatingTail];
    [titleLabel setNumberOfLines: 2.0f];
    [hunterBGView addSubview: titleLabel];
    ///11.子标题
    origin_y = titleLabel.frame.size.height + titleLabel.frame.origin.y;
    XZJ_CustomLabel *subTitleLabel  =[[XZJ_CustomLabel alloc] initWithFrame: CGRectMake(origin_x, origin_y, curScreenSize.width - origin_x - MARGIN_LEFT, titleLabel.frame.size.height)];
    [subTitleLabel setText: @"水上之都，世界著名历史名城,水天相接别样的夜晚"];
    [subTitleLabel setLineBreakMode: NSLineBreakByTruncatingTail];
    [subTitleLabel setNumberOfLines: 2];
    [subTitleLabel setFont: [UIFont systemFontOfSize: 11.0f]];
    [subTitleLabel setTextColor: [applicationClass methodOfTurnToUIColor: @"#797979"]];
    [hunterBGView addSubview: subTitleLabel];
    ///12.姓名
    origin_x = photoImageView.frame.origin.x;
    origin_y = photoImageView.frame.size.height + photoImageView.frame.origin.y;
    XZJ_CustomLabel *memberNameLabel = [[XZJ_CustomLabel alloc] initWithFrame: CGRectMake(origin_x, origin_y, photoImageView.frame.size.width, 20.0f)];
    [memberNameLabel setFont: [UIFont systemFontOfSize: 11.0f]];
    [memberNameLabel setTextColor: [applicationClass methodOfTurnToUIColor: @"#888888"]];
    [memberNameLabel setText: @"by michel 曾玲玲"];
    [memberNameLabel setTextAlignment: NSTextAlignmentCenter];
    [hunterBGView addSubview: memberNameLabel];
    ///13.个人介绍
    origin_x = memberNameLabel.frame.size.width + memberNameLabel.frame.origin.x + 10.0f;
    origin_y = subTitleLabel.frame.size.height + subTitleLabel.frame.origin.y;
    XZJ_CustomLabel *introduceLabel = [[XZJ_CustomLabel alloc] initWithFrame: CGRectMake(origin_x, origin_y, curScreenSize.width - origin_x, memberNameLabel.frame.size.height)];
    [introduceLabel setTextColor: [applicationClass methodOfTurnToUIColor: @"#c4c4c4"]];
    [introduceLabel setFont: [UIFont systemFontOfSize: 11.0f]];
    [introduceLabel setText: @"文职工作，热爱旅行"];
    [hunterBGView addSubview: introduceLabel];
    ///14.评星
    origin_x = memberNameLabel.frame.origin.x + 10.0f;
    origin_y = memberNameLabel.frame.size.height + memberNameLabel.frame.origin.y;
    CGFloat size_w = (PHOTO_IMAGE_HEIGHT - 20.0f) / 5.0f;
    for (NSInteger i = 0; i < 5; i++) {
        NSString *imageName = (i < 3 ? @"star_fill" :@"star_blank");
        UIImageView *imageView = [[UIImageView alloc] initWithFrame: CGRectMake(origin_x + i * size_w, origin_y, size_w, size_w)];
        [imageView setContentMode: UIViewContentModeScaleAspectFit];
        [imageView setImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: imageName ofType: @"png"]]];
        [hunterBGView addSubview: imageView];
    }
    ///15.标签
    origin_x = PHOTO_IMAGE_HEIGHT;
    origin_y += size_w + 30.0f;
    size_w = (curScreenSize.width - 2 * PHOTO_IMAGE_HEIGHT) / 3.0f;
    for(NSInteger i = 0; i < 3; i++){
        ///标签图标
        UIImageView *tagImageView = [[UIImageView alloc] initWithFrame: CGRectMake(origin_x + i * size_w, origin_y, size_w, TAG_IMAGE_HEIGHT)];
        [tagImageView setContentMode: UIViewContentModeScaleAspectFit];
        [hunterBGView addSubview: tagImageView];
        ///标签说明
        XZJ_CustomLabel *tagLabel = [[XZJ_CustomLabel alloc] initWithFrame: CGRectMake(tagImageView.frame.origin.x, tagImageView.frame.size.height + tagImageView.frame.origin.y, tagImageView.frame.size.width, 20.0f)];
        [tagLabel setTextAlignment: NSTextAlignmentCenter];
        [tagLabel setTextColor: [applicationClass methodOfTurnToUIColor: @"#929292"]];
        [tagLabel setFont: [UIFont systemFontOfSize: 10.0f]];
        [hunterBGView addSubview: tagLabel];
        switch (i) {
            case 0:
                [tagImageView setImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: @"icon_time" ofType: @"png"]]];
                [tagLabel setText: @"2-3小时"];
                break;
            case 1:
                [tagImageView setImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: @"icon_persons" ofType: @"png"]]];
                [tagLabel setText: @"1-6人"];
                break;
            case 2:
                [tagImageView setImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: @"icon_language" ofType: @"png"]]];
                [tagLabel setText: @"中文、英文"];
                break;
            default:
                break;
        }
    }
    
    ////
    origin_y = hunterBGView.frame.size.height + hunterBGView.frame.origin.y + 10.0f;
    [self loadTravelDetails: origin_y];
}

- (void)loadTravelDetails:(CGFloat) origin_y
{
    ///1.旅游详情主视图
    UIView *travelView = [[UIView alloc] initWithFrame: CGRectMake(0.0f, origin_y, curScreenSize.width, TRAVEL_VIEW_HEIGHT)];
    [travelView setBackgroundColor: [UIColor whiteColor]];
    [travelView.layer setShadowOpacity: 0.2f];
    [travelView.layer setShadowOffset: CGSizeMake(0.0f, 2.0f)];
    [mainScrollView addSubview: travelView];
    
    ///2.标题
    XZJ_CustomLabel *titleLabel = [[XZJ_CustomLabel alloc] initWithFrame: CGRectMake(0.0f, 0.0f, curScreenSize.width, 60.0f)];
    [titleLabel setText: @"旅程详情"];
    [titleLabel setTextColor: [applicationClass methodOfTurnToUIColor: @"#0f0f0f"]];
    [titleLabel setTextAlignment: NSTextAlignmentCenter];
    [titleLabel setFont: [UIFont systemFontOfSize: 16.0f]];
    [travelView addSubview: titleLabel];
    
    ///3.分割线
    origin_y = titleLabel.frame.size.height + titleLabel.frame.origin.y;
    UIView *lineView = [[UIView alloc] initWithFrame: CGRectMake(10.0f, origin_y, curScreenSize.width - 20.0f, 1.0f)];
    [lineView setBackgroundColor: [applicationClass methodOfTurnToUIColor: @"#dddddd"]];
    [travelView addSubview: lineView];
    
    ///4.路线
    origin_y += lineView.frame.size.height + 5.0f;
    CGFloat origin_x = 10.0f;
    for(NSInteger i = 0; i < 6; i++){
        ///地点名称
        XZJ_CustomLabel *tmpLabel = [[XZJ_CustomLabel alloc] initWithFrame: CGRectMake(origin_x, origin_y + (i > 2 ? 1 : 0) * 30.0f, LINE_LABEL_WIDTH, LINE_LABEL_HEIGHT)];
        [tmpLabel setFont: [UIFont systemFontOfSize: 13.0f]];
        [tmpLabel setText: @"威尼斯"];
        [tmpLabel setTextColor: [applicationClass methodOfTurnToUIColor: @"#4c4c4c"]];
        [tmpLabel setTextAlignment: NSTextAlignmentCenter];
        [travelView addSubview: tmpLabel];
        if(i < 2){
            origin_x = tmpLabel.frame.size.width + tmpLabel.frame.origin.x;
            ///线路
            UIImageView *tmpImageView = [[UIImageView alloc] initWithFrame: CGRectMake(origin_x, tmpLabel.frame.origin.y, LINE_LABEL_WIDTH / 2.0f, tmpLabel.frame.size.height)];
            [tmpImageView setImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: @"travel_line" ofType: @"png"]]];
            [tmpImageView setContentMode: UIViewContentModeScaleAspectFit];
            [travelView addSubview: tmpImageView];
            origin_x += LINE_LABEL_WIDTH / 2.0f;
        }
        else if(i == 2){
            origin_x = tmpLabel.frame.size.width + tmpLabel.frame.origin.x;
            ///线路
            UIImageView *tmpImageView = [[UIImageView alloc] initWithFrame: CGRectMake(origin_x, tmpLabel.frame.origin.y + tmpLabel.frame.size.height / 2.0f, LINE_LABEL_WIDTH / 2.0f, tmpLabel.frame.size.height)];
            [tmpImageView setImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: @"line_circle" ofType: @"png"]]];
            [travelView addSubview: tmpImageView];
            
            origin_x -= tmpLabel.frame.size.width;
        }
        else if(i > 2 && i < 5){
            origin_x -= LINE_LABEL_WIDTH / 2.0f;
            ///线路
            UIImageView *tmpImageView = [[UIImageView alloc] initWithFrame: CGRectMake(origin_x, tmpLabel.frame.origin.y, LINE_LABEL_WIDTH / 2.0f, tmpLabel.frame.size.height)];
            [tmpImageView setImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: @"line_left" ofType: @"png"]]];
            [tmpImageView setContentMode: UIViewContentModeScaleAspectFit];
            [travelView addSubview: tmpImageView];
            origin_x -= LINE_LABEL_WIDTH;
        }
    }
    
    ///5.分割线
    origin_y += 2 * LINE_LABEL_HEIGHT;
    lineView = [[UIView alloc] initWithFrame: CGRectMake(10.0f, origin_y, curScreenSize.width - 20.0f, 0.5f)];
    [lineView setBackgroundColor: [applicationClass methodOfTurnToUIColor: @"#dddddd"]];
    [travelView addSubview: lineView];
    
    ///6.旅行时长
    origin_y = lineView.frame.size.height + lineView.frame.origin.y;
    XZJ_CustomLabel *timeLabel = [[XZJ_CustomLabel alloc] initWithFrame: CGRectMake(MARGIN_LEFT, origin_y, travelView.frame.size.width - 2 * MARGIN_LEFT, LINE_LABEL_HEIGHT * 1.5f)];
    [timeLabel setText: @"旅程时长：2天"];
    [timeLabel setFont: [UIFont systemFontOfSize: 12.0f]];
    [timeLabel setTextColor: [applicationClass methodOfTurnToUIColor: @"#717171"]];
    [travelView addSubview: timeLabel];
    
    ///7.分割线
    origin_y = timeLabel.frame.size.height + timeLabel.frame.origin.y;
    lineView = [[UIView alloc] initWithFrame: CGRectMake(10.0f, origin_y, curScreenSize.width - 20.0f, 0.5f)];
    [lineView setBackgroundColor: [applicationClass methodOfTurnToUIColor: @"#dddddd"]];
    [travelView addSubview: lineView];
    
    ///8.旅程内容
    origin_y += lineView.frame.size.height + 10.0f;
    UIView *contentView = [[UIView alloc] initWithFrame: CGRectMake(MARGIN_LEFT, origin_y, travelView.frame.size.width - 2 * MARGIN_LEFT, TRAVEL_VIEW_HEIGHT - origin_y - 40.0f)];
    [travelView addSubview: contentView];
    origin_y = 0.0f;
    for(NSInteger i = 0; i < 2; i++)
    {
        ////文字
        CGRect labelFrame = CGRectMake(0.0f, origin_y, contentView.frame.size.width, 20.0f);
        UILabel *tmpLabel = [[UILabel alloc] initWithFrame: labelFrame];
        [tmpLabel setText: @"先坐火车到Stlicia火车站,然后边走边逛逛到圣马可广场，从那里坐船去Lido岛，然后去玻璃岛"];
        [tmpLabel setNumberOfLines: 0];
        [tmpLabel setLineBreakMode: NSLineBreakByTruncatingTail];
        [tmpLabel setFont: [UIFont systemFontOfSize: 12.0f]];
        [tmpLabel setTextColor: [applicationClass methodOfTurnToUIColor:@"#7a7a7a"]];
        [contentView addSubview: tmpLabel];
        labelFrame.size.height = [applicationClass methodOfGetLabelSize: tmpLabel].height;
        [tmpLabel setFrame:labelFrame];
        ////图片
        origin_y = tmpLabel.frame.size.height + tmpLabel.frame.origin.y + 10.0f;
        UIImageView *tmpImageView = [[UIImageView alloc] initWithFrame: CGRectMake(0.0f, origin_y, contentView.frame.size.width, CONTENT_IMAGE_HEIGHT)];
        [tmpImageView setImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: @"hp1" ofType: @"png"]]];
        [tmpImageView setContentMode: UIViewContentModeScaleAspectFill];
        [tmpImageView.layer setMasksToBounds: YES];
        [contentView addSubview: tmpImageView];
        origin_y += CONTENT_IMAGE_HEIGHT + 10.0f;
    }
    
    ////9.调整滚动视图的大小
    CGRect travelFrame = [travelView frame];
    travelFrame.size.height = origin_y + contentView.frame.origin.y + 60.0f;
    [travelView setFrame: travelFrame];
    
    ///10.查看更多按钮
    origin_y = travelFrame.size.height - 50.0f;
    UIImageView *moreImageView = [[UIImageView alloc] initWithFrame: CGRectMake((travelView.frame.size.width - 60.0f) / 2.0f, origin_y, 60.0f, 30.0f)];
    [moreImageView setImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: @"btn_more" ofType: @"png"]]];
    [moreImageView setContentMode: UIViewContentModeScaleAspectFit];
    [travelView addSubview: moreImageView];
    
    ///
    origin_y = travelFrame.size.height + travelFrame.origin.y + 10.0f;
    [self loadMeetingPlace: origin_y];
}

#pragma mark 加载见面地点的视图
- (void)loadMeetingPlace:(CGFloat) origin_y
{
    ///1.主视图
    UIView *meetPlaceView = [[UIView alloc] initWithFrame: CGRectMake(0.0f, origin_y, curScreenSize.width, MEETPLACE_VIEW_HEIGHT)];
    [meetPlaceView setBackgroundColor: [UIColor whiteColor]];
    [meetPlaceView.layer setShadowOpacity: 0.2f];
    [meetPlaceView.layer setShadowOffset: CGSizeMake(0.0f, 2.0f)];
    [mainScrollView addSubview: meetPlaceView];
    
    ///2.标题
    XZJ_CustomLabel *titleLabel = [[XZJ_CustomLabel alloc] initWithFrame: CGRectMake(MARGIN_LEFT, 0.0f, curScreenSize.width - MARGIN_LEFT, 60.0f)];
    [titleLabel setText: @"见面地点"];
    [titleLabel setTextColor: [applicationClass methodOfTurnToUIColor: @"#0f0f0f"]];
    [titleLabel setFont: [UIFont systemFontOfSize: 16.0f]];
    [meetPlaceView addSubview: titleLabel];
    
    ///3.分割线
    origin_y = titleLabel.frame.size.height + titleLabel.frame.origin.y;
    UIView *lineView = [[UIView alloc] initWithFrame: CGRectMake(10.0f, origin_y, curScreenSize.width - 20.0f, 1.0f)];
    [lineView setBackgroundColor: [applicationClass methodOfTurnToUIColor: @"#dddddd"]];
    [meetPlaceView addSubview: lineView];
    
    ///4.定位图标
    origin_y += lineView.frame.size.height + 10.0f;
    UIImageView *flagImageView = [[UIImageView alloc] initWithFrame: CGRectMake(MARGIN_LEFT, origin_y, 15.0f, 15.0f)];
    [flagImageView setImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: @"icon_flag" ofType: @"png"]]];
    [flagImageView setContentMode: UIViewContentModeScaleAspectFit];
    [meetPlaceView addSubview: flagImageView];
    
    ///5.位置信息
    CGFloat origin_x = flagImageView.frame.size.width + flagImageView.frame.origin.x + 5.0f;
    XZJ_CustomLabel *placeLabel = [[XZJ_CustomLabel alloc] initWithFrame: CGRectMake(origin_x, origin_y, meetPlaceView.frame.size.width - origin_x, flagImageView.frame.size.height)];
    [placeLabel setText: @"Ca'Rezzonico 雷佐尼科宫"];
    [placeLabel setTextColor: [applicationClass methodOfTurnToUIColor: @"#606060"]];
    [placeLabel setFont: [UIFont systemFontOfSize: 14.0f]];
    [meetPlaceView addSubview: placeLabel];
    
    ///6.地图  UNDO
    
    ///
    [self loadUserEvalutionView: meetPlaceView.frame.origin.y + MEETPLACE_VIEW_HEIGHT + 10.0f];
}


#pragma mark 用户评论视图
- (void)loadUserEvalutionView:(CGFloat) origin_y
{
    ///1.主视图
    UIView *mainView = [[UIView alloc] initWithFrame: CGRectMake(0.0f, origin_y, curScreenSize.width, EVALUTION_VIEW_HEIGHT)];
    [mainView setBackgroundColor: [UIColor whiteColor]];
    [mainView.layer setShadowOpacity: 0.2f];
    [mainView.layer setShadowOffset: CGSizeMake(0.0f, 2.0f)];
    [mainScrollView addSubview: mainView];
    
    ///2.标题
    XZJ_CustomLabel *titleLabel = [[XZJ_CustomLabel alloc] initWithFrame: CGRectMake(MARGIN_LEFT, 0.0f, curScreenSize.width - MARGIN_LEFT, 60.0f)];
    [titleLabel setText: @"用户评论"];
    [titleLabel setTextColor: [applicationClass methodOfTurnToUIColor: @"#0f0f0f"]];
    [titleLabel setFont: [UIFont systemFontOfSize: 16.0f]];
    [mainView addSubview: titleLabel];
    
    ///3.分割线
    origin_y = titleLabel.frame.size.height + titleLabel.frame.origin.y;
    UIView *lineView = [[UIView alloc] initWithFrame: CGRectMake(10.0f, origin_y, curScreenSize.width - 20.0f, 1.0f)];
    [lineView setBackgroundColor: [applicationClass methodOfTurnToUIColor: @"#dddddd"]];
    [mainView addSubview: lineView];
    
    ///4.评论信息
    origin_y += lineView.frame.size.height;
    CGFloat tmp_origin_y = 0.0f;
    CGFloat size_h = (EVALUTION_VIEW_HEIGHT - origin_y - 60.0f) / 2.0f;
    CGFloat origin_x = 0.0f;
    for(NSInteger i = 0; i < 2; i++){
        //背景
        UIView *tempView = [[UIView alloc] initWithFrame: CGRectMake(0.0f, origin_y+ i * (size_h + 1.0f), mainView.frame.size.width, size_h)];
        [tempView setBackgroundColor: [UIColor whiteColor]];
        [mainView addSubview : tempView];
        
        //头像
        UIImageView *photoImageView = [[UIImageView alloc] initWithFrame: CGRectMake(10.0f, 10.0f, tempView.frame.size.height - 40.0f,tempView.frame.size.height - 40.0f)];
        [photoImageView.layer setCornerRadius: photoImageView.frame.size.height / 2.0f];
        [photoImageView.layer setBorderColor: [applicationClass methodOfTurnToUIColor:@"#ffbdcf"].CGColor];
        [photoImageView.layer setBorderWidth: 2.0f];
        [photoImageView.layer setMasksToBounds: YES];
        [photoImageView setImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: @"photo" ofType: @"jpg"]]];
        [photoImageView setContentMode: UIViewContentModeScaleAspectFill];
        [tempView addSubview: photoImageView];
        //名称
        tmp_origin_y = photoImageView.frame.size.height + photoImageView.frame.origin.y;
        XZJ_CustomLabel *nameLabel = [[XZJ_CustomLabel alloc] initWithFrame: CGRectMake(photoImageView.frame.origin.x, tmp_origin_y, photoImageView.frame.size.width, 20.0f)];
        [nameLabel setTextAlignment: NSTextAlignmentCenter];
        [nameLabel setText: @"Liliyan 百花"];
        [nameLabel setFont: [UIFont systemFontOfSize: 10.0f]];
        [tempView addSubview: nameLabel];
        ///评分
        origin_x = photoImageView.frame.size.width + photoImageView.frame.origin.x + 10.0f;
        for(NSInteger j = 0; j < 5; j++){
            UIImageView *tmpImageView = [[UIImageView alloc] initWithFrame: CGRectMake(origin_x + 10.0f * j, photoImageView.frame.origin.y, 10.0f, 10.0f)];
            [tmpImageView setImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: @"star_fill" ofType: @"png"]]];
            [tmpImageView setContentMode: UIViewContentModeScaleAspectFit];
            [tempView addSubview: tmpImageView];
        }
        ///评论内容
        tmp_origin_y = photoImageView.frame.origin.y + 10.0f;
        XZJ_CustomLabel *contentLabel = [[XZJ_CustomLabel alloc] initWithFrame: CGRectMake(origin_x, tmp_origin_y, tempView.frame.size.width - origin_x - 10.0f, photoImageView.frame.size.height - tmp_origin_y)];
        [contentLabel setLineBreakMode: NSLineBreakByTruncatingTail];
        [contentLabel setNumberOfLines: 3];
        [contentLabel setFont: [UIFont systemFontOfSize: 13.0f]];
        [contentLabel setText: @"非常好的体验，很用心很周到，而且住的地方也很不错，介绍也很详细..."];
        [contentLabel setTextColor: [applicationClass methodOfTurnToUIColor: @"#7d7c7d"]];
        [tempView addSubview: contentLabel];
        ///时间
        tmp_origin_y = photoImageView.frame.size.height + photoImageView.frame.origin.y;
        XZJ_CustomLabel *timeLabel = [[XZJ_CustomLabel alloc] initWithFrame: CGRectMake(tempView.frame.size.width - 100.0f, tmp_origin_y, 90.0f, 25.0f)];
        [timeLabel setTextColor: [applicationClass methodOfTurnToUIColor: @"#c3c3c3"]];
        [timeLabel setTextAlignment: NSTextAlignmentRight];
        [timeLabel setFont: [UIFont systemFontOfSize: 10.0f]];
        [timeLabel setText: @"2015-11-12"];
        [tempView addSubview: timeLabel];
        ///下划线
        if(i == 0){
            lineView = [[UIView alloc] initWithFrame: CGRectMake(10.0f, tempView.frame.size.height + tempView.frame.origin.y, tempView.frame.size.width - 20.0f, 1.0f)];
            [lineView setBackgroundColor: [applicationClass methodOfTurnToUIColor: @"#dddddd"]];
            [mainView addSubview: lineView];
        }
    }
    
    ///5.查看更多按钮
    origin_y = mainView.frame.size.height - 50.0f;
    UIImageView *moreImageView = [[UIImageView alloc] initWithFrame: CGRectMake((mainView.frame.size.width - 60.0f) / 2.0f, origin_y, 60.0f, 30.0f)];
    [moreImageView setImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: @"btn_more" ofType: @"png"]]];
    [moreImageView setContentMode: UIViewContentModeScaleAspectFit];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget: self action: @selector(moreEvalutionButtonClick)];
    [moreImageView setUserInteractionEnabled: YES];
    [moreImageView addGestureRecognizer: tap];
    [mainView addSubview: moreImageView];
    
    ///6.加载猎人的其他旅游地点
    [self loadOtherLocation: mainView.frame.size.height + mainView.frame.origin.y + 10.0f ];
}

#pragma mark -
#pragma mark 猎人的其他旅游地点
- (void)loadOtherLocation:(CGFloat) origin_y
{
    ///1.主视图
    UIView *mainView = [[UIView alloc] initWithFrame: CGRectMake(0.0f, origin_y, curScreenSize.width, OTHER_VIEW_HEIGHT)];
    [mainView setBackgroundColor: [UIColor whiteColor]];
    [mainView.layer setShadowOpacity: 0.2f];
    [mainView.layer setShadowOffset: CGSizeMake(0.0f, 2.0f)];
    [mainScrollView addSubview: mainView];
    
    ///2.标题
    XZJ_CustomLabel *titleLabel = [[XZJ_CustomLabel alloc] initWithFrame: CGRectMake(MARGIN_LEFT, 0.0f, curScreenSize.width - MARGIN_LEFT, 60.0f)];
    [titleLabel setText: @"TA还可以带你玩"];
    [titleLabel setTextColor: [applicationClass methodOfTurnToUIColor: @"#0f0f0f"]];
    [titleLabel setTextAlignment: NSTextAlignmentCenter];
    [titleLabel setFont: [UIFont systemFontOfSize: 16.0f]];
    [mainView addSubview: titleLabel];
    
    ///4.猎人的其它旅游景点
    origin_y = titleLabel.frame.size.height + titleLabel.frame.origin.y;
    UIScrollView *hunterScrollView = [[UIScrollView alloc] initWithFrame: CGRectMake(0.0f, origin_y, mainView.frame.size.width, OTHER_VIEW_HEIGHT - origin_y)];
    [hunterScrollView setBackgroundColor: [UIColor clearColor]];
    [hunterScrollView setShowsHorizontalScrollIndicator: NO];
    [hunterScrollView setPagingEnabled: YES];
    [hunterScrollView setDelegate: self];
    [mainView addSubview: hunterScrollView];
    ///
    CGFloat size_w = hunterScrollView.frame.size.width - 80.0f;
    hunterViewWidth = size_w;
    for(NSInteger i = 0; i < 4; i++){
        TravelHunterView *hunterView = [[TravelHunterView alloc] initWithFrame: CGRectMake(i * size_w, 0.0f, size_w, hunterScrollView.frame.size.height - 20.0f)];
        [hunterView setBackgroundColor: [UIColor clearColor]];
        NSString *sex = (i % 2 == 0 ? @"男" : @"女");
        [hunterView setPhotoImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: @"photo" ofType: @"jpg"]] sex: sex];
        [hunterView setAppointButtonThemeColorBySex: sex];
        [hunterView.localImageView setImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: [NSString stringWithFormat: @"w%ld", (long)i % 2] ofType: @"png"]]];;
        [hunterView.nameLabel setText: @"by jonh 小博"];
        [hunterView.titleLabel setText: @"带你领略镜头下的圣母百花大教堂"];
        [hunterView.subTitleLabel setText: @"自由职业，摄影爱好者"];
        [hunterView setPricelText: @"$ 210"];
        [hunterView.appointNumberLabel setText: @"30人参与"];
        [hunterView.localLabel setText: @"荷兰，阿姆斯特丹"];
        [hunterView setStarLevel: 3];
        [hunterView.collectionNumberLabel setText: @"510"];
        [hunterScrollView addSubview: hunterView];
    }
    ///
    [hunterScrollView setContentSize: CGSizeMake(hunterScrollView.frame.size.width * 4.0f, hunterScrollView.frame.size.height)];
    [hunterScrollView setContentOffset: CGPointMake(hunterViewWidth - 40.0f, 0.0f)];
    curPageIndex = 1;
    
    ///加载推荐视图
    [self loadRecommonView: mainView.frame.size.height + mainView.frame.origin.y + 10.0f];
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    curPageIndex = scrollView.contentOffset.x / curScreenSize.width;
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    if(curPageIndex > 0)
        [scrollView setContentOffset: CGPointMake(curPageIndex * hunterViewWidth - 40.0f, 0.0f) animated: YES];
    else
        [scrollView setContentOffset: CGPointMake(0.0f, 0.0f) animated: YES];
}

#pragma mark -
#pragma mark 推荐旅游
- (void)loadRecommonView:(CGFloat) origin_y
{
    ///1.主视图
    UIView *mainView = [[UIView alloc] initWithFrame: CGRectMake(0.0f, origin_y, curScreenSize.width, RECOMMON_VIEW_HEIGHT)];
    [mainView setBackgroundColor: [UIColor whiteColor]];
    [mainView.layer setShadowOpacity: 0.2f];
    [mainView.layer setShadowOffset: CGSizeMake(0.0f, 2.0f)];
    [mainScrollView addSubview: mainView];
    
    ///2.标题
    XZJ_CustomLabel *titleLabel = [[XZJ_CustomLabel alloc] initWithFrame: CGRectMake(MARGIN_LEFT, 0.0f, curScreenSize.width - MARGIN_LEFT, 60.0f)];
    [titleLabel setText: @"推荐其他好玩的"];
    [titleLabel setTextColor: [applicationClass methodOfTurnToUIColor: @"#0f0f0f"]];
    [titleLabel setTextAlignment: NSTextAlignmentCenter];
    [titleLabel setFont: [UIFont systemFontOfSize: 16.0f]];
    [mainView addSubview: titleLabel];
    
    ///3.推荐的地方
    origin_y = titleLabel.frame.size.height + titleLabel.frame.origin.y;
    CGFloat size_h = (RECOMMON_VIEW_HEIGHT - origin_y) / 2.0f;
    for(NSInteger i = 0; i < 2; i++){
        TravelHunterView *hunterView = [[TravelHunterView alloc] initWithFrame: CGRectMake(0.0f, origin_y + i * size_h, mainView.frame.size.width, size_h)];
        [hunterView setBackgroundColor: [UIColor clearColor]];
        NSString *sex = (i % 2 == 0 ? @"男" : @"女");
        [hunterView setPhotoImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: @"photo" ofType: @"jpg"]] sex: sex];
        [hunterView setAppointButtonThemeColorBySex: sex];
        [hunterView.localImageView setImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: [NSString stringWithFormat: @"w%ld", (long)i % 2] ofType: @"png"]]];;
        [hunterView.nameLabel setText: @"by jonh 小博"];
        [hunterView.titleLabel setText: @"带你领略镜头下的圣母百花大教堂"];
        [hunterView.subTitleLabel setText: @"自由职业，摄影爱好者"];
        [hunterView setPricelText: @"$ 210"];
        [hunterView.appointNumberLabel setText: @"30人参与"];
        [hunterView.localLabel setText: @"荷兰，阿姆斯特丹"];
        [hunterView setStarLevel: 3];
        [hunterView.collectionNumberLabel setText: @"510"];
        [mainView addSubview: hunterView];
    }
    
    ///
    [mainScrollView setContentSize: CGSizeMake(curScreenSize.width, mainView.frame.size.height + mainView.frame.origin.y)];
}

#pragma mark -
#pragma mark 预约按钮
- (void)appointButtonClick
{
    if(!mainMaskView)
    {
        ///1.遮挡视图
        mainMaskView = [[UIView alloc] initWithFrame: CGRectMake(0.0f, 0.0f, curScreenSize.width, curScreenSize.height + 64.0f)];
        [mainMaskView setBackgroundColor: [[UIColor alloc] initWithWhite: 0.2f alpha: 0.5f]];
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget: self action: @selector(mainMaskViewClick)];
        [mainMaskView addGestureRecognizer: tap];
        [[[UIApplication sharedApplication] keyWindow] addSubview: mainMaskView];
        ///2.底部背景
        cardBottomView = [[UIView alloc] initWithFrame: CGRectMake(0.0f, mainMaskView.frame.size.height - CARD_BOTTOM_HEIGHT, curScreenSize.width , CARD_BOTTOM_HEIGHT)];
        [cardBottomView setBackgroundColor: [applicationClass methodOfTurnToUIColor: @"#ff3647"]];
        [cardBottomView setContentMode: UIViewContentModeScaleAspectFit];
        [mainMaskView addSubview: cardBottomView];
        ///3.左边三角形
        UIImageView *tempImageView = [[UIImageView alloc] initWithFrame: CGRectMake(0.0f, cardBottomView.frame.origin.y - 10.0f, 20.0f, 10.0f)];
        [tempImageView setImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: @"rect_left" ofType: @"png"]]];
        [mainMaskView addSubview: tempImageView];
        ///3.右边三角形
        tempImageView = [[UIImageView alloc] initWithFrame: CGRectMake(curScreenSize.width - 20.0f, cardBottomView.frame.origin.y - 10.0f, 20.0f, 10.0f)];
        [tempImageView setImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: @"rect_right" ofType: @"png"]]];
        [mainMaskView addSubview: tempImageView];
        ///4.操作按钮
        cardOperateButton = [[UIButton alloc] initWithFrame: CGRectMake(curScreenSize.width - 120.0f, 10.0f, 80.0f, CARD_BOTTOM_HEIGHT - 20.0f)];
        [cardOperateButton.layer setCornerRadius: 3.0f];
        [cardOperateButton.layer setBorderWidth: 0.5f];
        [cardOperateButton.layer setBorderColor:[UIColor whiteColor].CGColor];
        [cardOperateButton setTitleColor: [UIColor whiteColor] forState: UIControlStateNormal];
        [cardOperateButton.titleLabel setFont: [UIFont systemFontOfSize: 14.0f]];
        [cardOperateButton addTarget: self action: @selector(cardOperateButtonClick:) forControlEvents: UIControlEventTouchUpInside];
        [cardBottomView addSubview: cardOperateButton];
    }
    [mainMaskView setHidden: NO];
    [[[UIApplication sharedApplication] keyWindow] bringSubviewToFront: mainMaskView];
    [self loadInfoChecked];
}


#pragma mark -
#pragma mark 加载旅游原因的视图
- (void)loadTravelReasonView
{
    CGFloat carHeight = curScreenSize.height * 4 / 5;
    [cardOperateButton setTag: 1];
    [cardOperateButton setTitle: @"下一步" forState: UIControlStateNormal];
    if(!travelReasonView)
    {
        ///1.旅程原因主视图
        travelReasonView = [[UIView alloc] initWithFrame: CGRectMake(CARD_MARGIN_LEFT, mainMaskView.frame.size.height - CARD_BOTTOM_HEIGHT + 10.0f, curScreenSize.width - 2 * CARD_MARGIN_LEFT, 0.0f)];
        [travelReasonView setBackgroundColor: [UIColor whiteColor]];
        [travelReasonView.layer setCornerRadius: 5.0f];
        [mainMaskView insertSubview: travelReasonView belowSubview: cardBottomView];
        
        ///2.内容
        CGFloat size_h = (carHeight - 20.0f) / 2.0f;
        CGFloat origin_y = 0.0f, origin_x = 0.0f;
        for(NSInteger i = 0; i < 2; i++){
            ///背景
            UIView *tempView = [[UIView alloc] initWithFrame: CGRectMake(0.0f, i * (size_h), travelReasonView.frame.size.width, size_h)];
            [travelReasonView addSubview: tempView];
            ///圆点图标
            UIView *iconView = [[UIView alloc] initWithFrame: CGRectMake(10.0f, 15.0f, 6.0f, 6.0f)];
            [iconView setBackgroundColor: [applicationClass methodOfTurnToUIColor: @"#fb1539"]];
            [iconView.layer setCornerRadius: iconView.frame.size.height / 2.0f];
            [tempView addSubview: iconView];
            ///标题
            origin_x = iconView.frame.size.width + iconView.frame.origin.x + 5.0f;
            XZJ_CustomLabel *titleLabel = [[XZJ_CustomLabel alloc] initWithFrame: CGRectMake(origin_x, 0.0f, travelReasonView.frame.size.width - origin_x - 10.0f, 40.0f)];
            [titleLabel setFont: [UIFont systemFontOfSize: 14.0f]];
            [titleLabel setTextColor: [applicationClass methodOfTurnToUIColor: @"#4c4d4e"]];
            [tempView addSubview: titleLabel];
            ///输入框
            origin_y = titleLabel.frame.size.height + titleLabel.frame.origin.y;
            UITextView *textView = [[UITextView alloc] initWithFrame: CGRectMake(10.0f, origin_y, tempView.frame.size.width - 20.0f, tempView.frame.size.height - origin_y - 20.0f)];
            [textView setText: @"请输入..."];
            [textView.layer setCornerRadius: 5.0f];
            [textView.layer setBorderColor:[applicationClass methodOfTurnToUIColor: @"#e0e1e2"].CGColor];
            [textView.layer setBorderWidth: 1.0f];
            [textView setTextColor: [applicationClass methodOfTurnToUIColor: @"#b4b5b6"]];
            [textView setDelegate: self];
            [textView setTag: i];
            [textView setKeyboardType: UIKeyboardTypeNumberPad];
            [tempView addSubview: textView];
            ///剩余字数
            origin_y = textView.frame.size.height + textView.frame.origin.y;
            XZJ_CustomLabel *numberLabel = [[XZJ_CustomLabel alloc] initWithFrame: CGRectMake(10.0f, origin_y, tempView.frame.size.width - 20.0f, 20.0f)];
            [numberLabel setText: @"您还可以输入300个字"];
            [numberLabel setFont: [UIFont systemFontOfSize: 12.0f]];
            [numberLabel setTextColor: [applicationClass methodOfTurnToUIColor: @"#c6c7c8"]];
            [numberLabel setTextAlignment: NSTextAlignmentRight];
            [tempView addSubview: numberLabel];
            ///
            switch (i) {
                case 0:
                    [titleLabel setText: @"请向城市猎人说明此次出行的目的:"];
                    break;
                case 1:
                    [titleLabel setText: @"请向城市猎人简单的介绍一下自己:"];
                    break;
                default:
                    break;
            }
        }
    }
    [UIView animateWithDuration: 0.3f animations: ^{
        CGRect frame =  CGRectMake(CARD_MARGIN_LEFT, mainMaskView.frame.size.height - carHeight - CARD_BOTTOM_HEIGHT + 10.0f, curScreenSize.width - 2 * CARD_MARGIN_LEFT, carHeight);
        [travelReasonView setFrame: frame];
    }];
}

#pragma mark -
#pragma mark 加载预订条款
- (void)loadOrderProtocol
{
    CGFloat carHeight = curScreenSize.height * 4 / 5;
    [cardOperateButton setTitle: @"完成" forState: UIControlStateNormal];
    [cardOperateButton setTag: 2];
    if(!orderProtocolView)
    {
        ///1.旅程原因主视图
        orderProtocolView = [[UIView alloc] initWithFrame: CGRectMake(CARD_MARGIN_LEFT, mainMaskView.frame.size.height - CARD_BOTTOM_HEIGHT + 10.0f, curScreenSize.width - 2 * CARD_MARGIN_LEFT, 0.0f)];
        [orderProtocolView setBackgroundColor: [UIColor whiteColor]];
        [orderProtocolView.layer setCornerRadius: 5.0f];
        [mainMaskView insertSubview: orderProtocolView belowSubview: cardBottomView];
        
        ///2.标题
        XZJ_CustomLabel *titleLabel = [[XZJ_CustomLabel alloc] initWithFrame: CGRectMake(0.0f, 0.0f, orderProtocolView.frame.size.width, 50.0f)];
        [titleLabel setFont: [UIFont systemFontOfSize: 18.0f]];
        [titleLabel setTextColor: [applicationClass methodOfTurnToUIColor: @"#4c4d4e"]];
        [titleLabel setText: @"预订条款及协议"];
        [titleLabel setTextAlignment: NSTextAlignmentCenter];
        [orderProtocolView addSubview: titleLabel];
        
        ///3.具体条款和协议
        CGFloat origin_y = titleLabel.frame.size.height + titleLabel.frame.origin.y;
        UITextView *textView = [[UITextView alloc] initWithFrame: CGRectMake(10.0f, origin_y, orderProtocolView.frame.size.width - 20.0f, carHeight - origin_y - 80.0f)];
        [textView setText: @"第一条 相关概念和注释"];
        [textView.layer setBorderColor:[applicationClass methodOfTurnToUIColor: @"#e0e1e2"].CGColor];
        [textView.layer setBorderWidth: 1.0f];
        [textView setTextColor: [applicationClass methodOfTurnToUIColor: @"#b4b5b6"]];
        [textView setEditable: NO];
        [orderProtocolView addSubview: textView];
        
        ///4.复选框
        origin_y = textView.frame.size.height + textView.frame.origin.y + 20.0f;
        UIButton *chechedButton = [[UIButton alloc] initWithFrame: CGRectMake(orderProtocolView.frame.size.width / 3.0f - 20.0f, origin_y, 20.0f, 20.0f)];
        [chechedButton setImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: @"selection_none" ofType: @"png"]] forState: UIControlStateNormal];
        [chechedButton setImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: @"selection_checked" ofType: @"png"]] forState: UIControlStateNormal];
        [orderProtocolView addSubview: chechedButton];
        
        ///5.用户协议
        CGFloat origin_x = chechedButton.frame.size.width + chechedButton.frame.origin.x + 5.0f;
        XZJ_CustomLabel *protocolLabel = [[XZJ_CustomLabel alloc] initWithFrame: CGRectMake(origin_x, origin_y, orderProtocolView.frame.size.width - origin_x, 20.0f)];
        NSMutableAttributedString *attributeString = [[NSMutableAttributedString alloc] initWithString: @"我已阅读并同意用户协议"];
        [attributeString addAttribute: NSForegroundColorAttributeName value: [applicationClass methodOfTurnToUIColor: @"#7f8081"] range: NSMakeRange(0, 7)];
        [attributeString addAttribute: NSForegroundColorAttributeName value: [applicationClass methodOfTurnToUIColor: @"#65aefc"] range: NSMakeRange(7, 4)];
        [protocolLabel setFont: [UIFont systemFontOfSize: 14.0f]];
        [protocolLabel setAttributedText: attributeString];
        [orderProtocolView addSubview: protocolLabel];
    }
    [UIView animateWithDuration: 0.3f animations: ^{
        CGRect frame =  CGRectMake(CARD_MARGIN_LEFT, mainMaskView.frame.size.height - carHeight - CARD_BOTTOM_HEIGHT + 10.0f, curScreenSize.width - 2 * CARD_MARGIN_LEFT, carHeight);
        [orderProtocolView setFrame: frame];
    }];
}

#pragma mark -
#pragma mark 加载信息核对页面
- (void)loadInfoChecked
{
    CGFloat carHeight = curScreenSize.height * 4 / 5;
    [cardOperateButton setTag: 0];
    [cardOperateButton setTitle: @"下一步" forState: UIControlStateNormal];
    if(!infoCheckedView)
    {
        ///1.旅程原因主视图
        infoCheckedView = [[UIView alloc] initWithFrame: CGRectMake(CARD_MARGIN_LEFT, mainMaskView.frame.size.height - CARD_BOTTOM_HEIGHT + 10.0f, curScreenSize.width - 2 * CARD_MARGIN_LEFT, 0.0f)];
        [infoCheckedView setBackgroundColor: [UIColor whiteColor]];
        [infoCheckedView.layer setCornerRadius: 5.0f];
        [mainMaskView insertSubview: infoCheckedView belowSubview: cardBottomView];
        
        ///2.圆点图标
        UIView *iconView = [[UIView alloc] initWithFrame: CGRectMake(10.0f, 15.0f, 10.0f, 10.0f)];
        [iconView setBackgroundColor: [applicationClass methodOfTurnToUIColor: @"#fb1539"]];
        [iconView.layer setCornerRadius: iconView.frame.size.height / 2.0f];
        [infoCheckedView addSubview: iconView];
        
        ///3.标题
        CGFloat origin_x = iconView.frame.size.width + iconView.frame.origin.x + 5.0f;
        XZJ_CustomLabel *titleLabel = [[XZJ_CustomLabel alloc] initWithFrame: CGRectMake(origin_x, 0.0f, infoCheckedView.frame.size.width - origin_x - 10.0f, 40.0f)];
        [titleLabel setFont: [UIFont boldSystemFontOfSize: 16.0f]];
        [titleLabel setTextColor: [applicationClass methodOfTurnToUIColor: @"#4c4d4e"]];
        [titleLabel setText: @"填写信息"];
        [infoCheckedView addSubview: titleLabel];
        
        ///4.表格信息
        CGFloat origin_y = titleLabel.frame.size.height +titleLabel.frame.origin.y;
        UIView *tableView = [[UIView alloc] initWithFrame: CGRectMake(10.0f, origin_y, infoCheckedView.frame.size.width - 20.0f, carHeight - origin_y - 50.0f)];
        [tableView setBackgroundColor: [UIColor whiteColor]];
        [tableView.layer setCornerRadius: 4.0f];
        [tableView.layer setBorderWidth: 1.0f];
        [tableView.layer setBorderColor: [applicationClass methodOfTurnToUIColor: @"#e1e1e1"].CGColor];
        [infoCheckedView addSubview: tableView];
        
        CGFloat size_h = (tableView.frame.size.height - 5.0f) / 6.5f;
        for(NSInteger i = 0; i < 6; i++){
            //标题
            XZJ_CustomLabel *titleLabel = [[XZJ_CustomLabel alloc] initWithFrame: CGRectMake(10.0f, (i >= 1 ? (i - 1) * (size_h + 1.0f) + 1.5f * size_h + 1.0f : 0.0f), 60.0f, (i == 0 ? 1.5f * size_h : size_h))];
            [titleLabel setTextAlignment: NSTextAlignmentCenter];
            [titleLabel setFont: [UIFont systemFontOfSize: 15.0f]];
            [titleLabel setTextColor: [applicationClass methodOfTurnToUIColor: @"#7a7a7a"]];
            [tableView addSubview: titleLabel];
            //内容
            origin_x = titleLabel.frame.size.width + titleLabel.frame.origin.x + 5.0f;
            BOOL isShowLine = false;
            switch (i) {
                case 0:
                {
                    [titleLabel setText: @"旅行名称"];
                    XZJ_CustomLabel *contentLabel = [[XZJ_CustomLabel alloc] initWithFrame: CGRectMake(origin_x + 10.0f, titleLabel.frame.origin.y, tableView.frame.size.width - origin_x - 20.0f, titleLabel.frame.size.height)];
                    [contentLabel setFont: [UIFont systemFontOfSize: 13.0f]];
                    [contentLabel setNumberOfLines: 3];
                    [contentLabel setLineBreakMode: NSLineBreakByTruncatingTail];
                    [contentLabel setTextColor: [applicationClass methodOfTurnToUIColor: @"#454545"]];
                    [contentLabel setText: @"我在小船上等你，与你一起感受浪漫威尼斯"];
                    [tableView addSubview: contentLabel];
                    isShowLine = YES;
                    break;
                }
                case 1:
                {
                    [titleLabel setText: @"猎人信息"];
                    UIButton *tempButton = [[UIButton alloc] initWithFrame: CGRectMake(origin_x, titleLabel.frame.origin.y, tableView.frame.size.width - origin_x, size_h)];
                    [tempButton setImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: @"icon_arrow" ofType: @"png"]] forState: UIControlStateNormal];
                    [tempButton setImageEdgeInsets: UIEdgeInsetsMake(size_h / 2.5f, tempButton.frame.size.width - 15.0f, size_h / 2.5f, 10.0f)];
                    [tableView addSubview: tempButton];
                    isShowLine = YES;
                    break;
                }
                case 2:
                {
                    [titleLabel setText: @"出行日期"];
                    UIButton *tempButton = [[UIButton alloc] initWithFrame: CGRectMake(origin_x, titleLabel.frame.origin.y, tableView.frame.size.width - origin_x, size_h)];
                    [tempButton setImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: @"icon_arrow" ofType: @"png"]] forState: UIControlStateNormal];
                    [tempButton setImageEdgeInsets: UIEdgeInsetsMake(size_h / 2.5f, tempButton.frame.size.width - 15.0f, size_h / 2.5f, 10.0f)];
                    [tableView addSubview: tempButton];
                    isShowLine = YES;
                    //时间
                    XZJ_CustomLabel *timeLabel = [[XZJ_CustomLabel alloc] initWithFrame: CGRectMake(0.0f, 0.0f, tempButton.frame.size.width - 20.0f, tempButton.frame.size.height)];
                    [timeLabel setFont: [UIFont systemFontOfSize: 14.0f]];
                    [timeLabel setTextAlignment: NSTextAlignmentRight];
                    [timeLabel setTextColor: [applicationClass methodOfTurnToUIColor: @"#636363"]];
                    [timeLabel setText: @"201-12-15"];
                    [tempButton addSubview: timeLabel];
                    break;
                }
                case 3:{
                    [titleLabel setText: @"预订数量"];
                    isShowLine = YES;
                    ///减号
                    origin_x = tableView.frame.size.width / 1.8f;
                    CGFloat tmpSize_h = size_h - 20.0f;
                    UIButton *reduceButton = [[UIButton alloc] initWithFrame: CGRectMake(origin_x, titleLabel.frame.origin.y +  10.0f, tmpSize_h, tmpSize_h)];
                    [reduceButton setBackgroundColor: [applicationClass methodOfTurnToUIColor: @"#ef5052"]];
                    [reduceButton setTitleColor: [UIColor whiteColor] forState: UIControlStateNormal];
                    [reduceButton setImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: @"icon_reduce" ofType: @"png"]] forState: UIControlStateNormal];
                    [reduceButton setImageEdgeInsets: UIEdgeInsetsMake(12.0f, 12.0f, 12.0f, 12.0f)];
                    [reduceButton setTag: 0];
                    [reduceButton addTarget: self action: @selector(operateNumberClick:) forControlEvents: UIControlEventTouchUpInside];
                    [tableView addSubview: reduceButton];
                    
                    ///8.人数
                    origin_y = reduceButton.frame.origin.y;
                    origin_x = reduceButton.frame.size.width + reduceButton.frame.origin.x;
                    numberTextfiled = [[UITextField alloc] initWithFrame: CGRectMake(origin_x, origin_y, tmpSize_h, tmpSize_h)];
                    [numberTextfiled setText: @"1"];
                    [numberTextfiled setTextAlignment: NSTextAlignmentCenter];
                    [numberTextfiled setFont: [UIFont systemFontOfSize: 13.0f]];
                    [numberTextfiled setTextColor: [applicationClass methodOfTurnToUIColor: @"#323437"]];
                    [numberTextfiled.layer setBorderWidth: 0.5f];
                    [numberTextfiled.layer setBorderColor: [applicationClass methodOfTurnToUIColor: @"#ef5052"].CGColor];
                    [numberTextfiled setKeyboardType: UIKeyboardTypeNumberPad];
                    [numberTextfiled setDelegate: self];
                    [tableView addSubview: numberTextfiled];
                    
                    ///9.加号
                    origin_x = numberTextfiled.frame.size.width + numberTextfiled.frame.origin.x;
                    UIButton *addButton = [[UIButton alloc] initWithFrame: CGRectMake(origin_x, origin_y , tmpSize_h, tmpSize_h)];
                    [addButton setBackgroundColor: [applicationClass methodOfTurnToUIColor: @"#ef5052"]];
                    [addButton setTitleColor: [UIColor whiteColor] forState: UIControlStateNormal];
                    [addButton setImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: @"icon_add" ofType: @"png"]] forState: UIControlStateNormal];
                    [addButton setImageEdgeInsets: UIEdgeInsetsMake(12.0f, 12.0f, 12.0f, 12.0f)];
                    [addButton setTag: 1];
                    [addButton addTarget: self action: @selector(operateNumberClick:) forControlEvents: UIControlEventTouchUpInside];
                    [tableView addSubview: addButton];
                    break;
                }
                case 4:{
                    [titleLabel setText: @"预订价格"];
                    isShowLine = YES;
                    ///
                    XZJ_CustomLabel *valueLabel = [[XZJ_CustomLabel alloc] initWithFrame: CGRectMake(origin_x, titleLabel.frame.origin.y, tableView.frame.size.width - origin_x - 10.0f, size_h)];
                    [valueLabel setTextAlignment: NSTextAlignmentRight];
                    [valueLabel setTextColor: [applicationClass methodOfTurnToUIColor: @"#686868"]];
                    [valueLabel setFont: [UIFont systemFontOfSize: 14.0f]];
                    [valueLabel setText: @"$128.00"];
                    [tableView addSubview: valueLabel];
                    break;
                }
                case 5:{
                    [titleLabel setText: @"见面地点"];
                    isShowLine = NO;
                    ///
                    XZJ_CustomLabel *valueLabel = [[XZJ_CustomLabel alloc] initWithFrame: CGRectMake(origin_x, titleLabel.frame.origin.y, tableView.frame.size.width - origin_x - 10.0f, size_h)];
                    [valueLabel setTextAlignment: NSTextAlignmentRight];
                    [valueLabel setTextColor: [applicationClass methodOfTurnToUIColor: @"#515151"]];
                    [valueLabel setFont: [UIFont systemFontOfSize: 14.0f]];
                    [valueLabel setText: @"Ca'Rezzonico 雷佐尼科宫"];
                    [tableView addSubview: valueLabel];
                    break;
                }
                default:
                    break;
            }
            if(isShowLine){
                UIView *lineView = [[UIView alloc] initWithFrame: CGRectMake(0.0f, titleLabel.frame.size.height + titleLabel.frame.origin.y, tableView.frame.size.width, 1.0f)];
                [lineView setBackgroundColor: [applicationClass methodOfTurnToUIColor: @"#e1e1e1"]];
                [tableView addSubview: lineView];
            }
        }
    }
    [UIView animateWithDuration: 0.3f animations: ^{
        CGRect frame =  CGRectMake(CARD_MARGIN_LEFT, mainMaskView.frame.size.height - carHeight - CARD_BOTTOM_HEIGHT + 10.0f, curScreenSize.width - 2 * CARD_MARGIN_LEFT, carHeight);
        [infoCheckedView setFrame: frame];
    }];
}

#pragma mark -
#pragma mark 预订人数的操作事件
- (void)operateNumberClick:(UIButton *)sender
{
    NSInteger curNumber = [[numberTextfiled text] integerValue];
    switch ([sender tag]) {
        case 0:
        {
            if(curNumber > 1){
                [numberTextfiled setText: [[NSNumber numberWithInteger: --curNumber] stringValue]];
            }
            break;
        }
        case 1:
        {
            [numberTextfiled setText: [[NSNumber numberWithInteger: ++curNumber] stringValue]];
//            if(curNumber < maxNumber){
//                
//            }
        }
        default:
            break;
    }
}

#pragma mark -
#pragma mark 操作按钮点击事件
- (void)cardOperateButtonClick:(UIButton *)sender
{
    switch ([sender tag]) {
        case 0:
        {
            [UIView animateWithDuration: 0.3f animations:  ^{
                CGRect frame = [infoCheckedView frame];
                frame.origin.y = mainMaskView.frame.size.height - CARD_BOTTOM_HEIGHT + 10.0f;
                frame.size.height = 0.0f;
                [infoCheckedView setFrame: frame];
            }completion: ^(BOOL finish){
                if(finish){
                    [self loadTravelReasonView];
                }
            }];
            break;
        }
        case 1:{
            [UIView animateWithDuration: 0.3f animations:  ^{
                CGRect frame = [infoCheckedView frame];
                frame.origin.y = mainMaskView.frame.size.height - CARD_BOTTOM_HEIGHT + 10.0f;
                frame.size.height = 0.0f;
                [travelReasonView setFrame: frame];
            }completion: ^(BOOL finish){
                if(finish){
                    [self loadOrderProtocol];
                }
            }];
            break;
        }
        case 2:{
            [UIView animateWithDuration: 0.3f animations:  ^{
                CGRect frame = [infoCheckedView frame];
                frame.origin.y = mainMaskView.frame.size.height - CARD_BOTTOM_HEIGHT + 10.0f;
                frame.size.height = 0.0f;
                [orderProtocolView setFrame: frame];
            }completion: ^(BOOL finish){
                if(finish){
//                    [self loadOrderProtocol];
                }
            }];
            break;
        }
        default:
            break;
    }
}

#pragma mark -
#pragma mark textView委托
- (void)textViewDidBeginEditing:(UITextView *)textView
{
    isEdit = YES;
    curResponser = textView;
    if([[textView text] isEqualToString: @"请输入..."]){
        [textView setText: @""];
    }
    [applicationClass methodOfResizeView: [textView tag] * 120.0f + 20.0f target: mainMaskView isNavigation: NO];
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    isEdit = NO;
    [curResponser resignFirstResponder];
}


#pragma mark -
#pragma mark mainMask隐藏操作
- (void)mainMaskViewClick
{
    if(!isEdit){
        [UIView animateWithDuration: 0.3f animations:  ^{
            CGRect frame = [infoCheckedView frame];
            frame.origin.y = mainMaskView.frame.size.height - CARD_BOTTOM_HEIGHT + 10.0f;
            frame.size.height = 0.0f;
            if(infoCheckedView){
                [infoCheckedView setFrame: frame];
            }
            if(travelReasonView){
                [travelReasonView setFrame: frame];
            }
            if(orderProtocolView){
                [orderProtocolView setFrame: frame];
            }
        }completion: ^(BOOL finish){
            if(finish){
                [mainMaskView setHidden: YES];
            }
        }];
    }
    else{
        isEdit = NO;
        [applicationClass methodOfResizeView: 0.0f target:mainMaskView isNavigation: NO];
        [curResponser resignFirstResponder];
    }
}

#pragma mark -
#pragma mark 评论的更多按钮
- (void)moreEvalutionButtonClick
{
    EvaluationListViewController *evalutionVC = [[EvaluationListViewController alloc] init];
    [self.navigationController pushViewController: evalutionVC animated: YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
