//
//  AppointmentViewController.h
//  WorldView
//
//  Created by XZJ on 11/10/15.
//  Copyright © 2015 XZJ. All rights reserved.
//

#import "BaseViewController.h"
#import "TravelHunterView.h"
#import "EvaluationListViewController.h"
@interface AppointmentViewController : BaseViewController<UIScrollViewDelegate, UITextFieldDelegate, UITextViewDelegate>
{
    UIScrollView *mainScrollView;
    CGFloat hunterViewWidth;
    NSInteger curPageIndex;
    UIView *mainMaskView;
    UIView *travelReasonView;
    UIView *orderProtocolView;
    UIView *cardBottomView;
    UIView *infoCheckedView;
    UITextField *numberTextfiled;
    UIButton *cardOperateButton;
    id curResponser;
    BOOL isEdit;
}
@end
