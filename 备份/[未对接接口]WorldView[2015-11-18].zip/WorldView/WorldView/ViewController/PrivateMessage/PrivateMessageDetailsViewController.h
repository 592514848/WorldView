//
//  PrivateMessageDetailsViewController.h
//  WorldView
//
//  Created by WorldView on 15/11/14.
//  Copyright © 2015年 XZJ. All rights reserved.
//

#import "BaseViewController.h"

@interface PrivateMessageDetailsViewController : BaseViewController<UITableViewDataSource, UITableViewDelegate>
{
    UITableView *mainTableView;
}
@end
