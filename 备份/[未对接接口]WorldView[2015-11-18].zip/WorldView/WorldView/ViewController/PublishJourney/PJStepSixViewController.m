//
//  PJStepSixViewController.m
//  WorldView
//
//  Created by XZJ on 11/6/15.
//  Copyright © 2015 XZJ. All rights reserved.
//
#define STEP_IMAGEVIEW_HEIGHT 15.0F
#define MARGIN_LEFT 15.0F
#define TITLE_LABEL_HEIGHT 40.0F
#define TITLE_VALUE_HEIGHT 40.0F
#define TEXTVIEW_HEIGHT 130.0F
#define BUTTON_HEIGHT 35.0F
#define BUTTON_WIDTH 100.0F

#import "PJStepSixViewController.h"
#import "PJStepSevenViewController.h"

@implementation PJStepSixViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setTitle: @"发布旅程"];
    [self loadMainView];
}

- (void)loadMainView
{
    ///1.设置进度条
    UIImageView *stepImageView = [[UIImageView alloc] initWithFrame: CGRectMake(10.0f, 10.0f, curScreenSize.width - 20.0f, STEP_IMAGEVIEW_HEIGHT)];
    [stepImageView setImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: @"step_six" ofType: @"png"]]];
    [stepImageView setContentMode: UIViewContentModeScaleAspectFit];
    [self.view addSubview: stepImageView];
    
    ///2.主滚动视图
    CGFloat origin_y = stepImageView.frame.size.height + stepImageView.frame.origin.y + 20.0f;
    UIScrollView *mainScrollView = [[UIScrollView alloc] initWithFrame: CGRectMake(0.0f, origin_y, curScreenSize.width, curScreenSize.height - origin_y)];
    [mainScrollView setBackgroundColor: [UIColor clearColor]];
    [mainScrollView setShowsVerticalScrollIndicator: NO];
    [self.view addSubview: mainScrollView];
    
    ///4.服务名称
    origin_y = 0.0f;
    XZJ_CustomLabel *titleLabel = [[XZJ_CustomLabel alloc] initWithFrame: CGRectMake(MARGIN_LEFT, origin_y, mainScrollView.frame.size.width - 20.0f, TITLE_LABEL_HEIGHT)];
    [titleLabel setText: @"添加封面照片："];
    [titleLabel setFont: [UIFont boldSystemFontOfSize: 15.0f]];
    [mainScrollView addSubview: titleLabel];
    
    ///4.上一步按钮
    origin_y += TITLE_LABEL_HEIGHT;
    CGFloat margin = (curScreenSize.width - 2 * BUTTON_WIDTH) / 3.0f;
    UIButton *lastStepButton = [[UIButton alloc] initWithFrame: CGRectMake(margin, origin_y, BUTTON_WIDTH, BUTTON_HEIGHT)];
    [lastStepButton setBackgroundColor: [UIColor whiteColor]];
    [lastStepButton setTitleColor: [applicationClass methodOfTurnToUIColor: @"#ef5052"] forState: UIControlStateNormal];
    [lastStepButton setTitle: @"上一步" forState: UIControlStateNormal];
    [lastStepButton.layer setCornerRadius: 3.0f];
    [lastStepButton.titleLabel setFont: [UIFont systemFontOfSize: 14.0f]];
    [lastStepButton.layer setBorderWidth: 0.5f];
    [lastStepButton setTag: 0];
    [lastStepButton.layer setBorderColor:[applicationClass methodOfTurnToUIColor: @"#ef5052"].CGColor];
    [lastStepButton addTarget:self action: @selector(stepButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    [mainScrollView addSubview: lastStepButton];
    
    ///5.下一步按钮
    CGFloat origin_x = 2 * margin + BUTTON_WIDTH;
    UIButton *nextStepButton = [[UIButton alloc] initWithFrame: CGRectMake(origin_x, origin_y, BUTTON_WIDTH, BUTTON_HEIGHT)];
    [nextStepButton setBackgroundColor: [applicationClass methodOfTurnToUIColor: @"#ef5052"]];
    [nextStepButton setTitleColor: [UIColor whiteColor] forState: UIControlStateNormal];
    [nextStepButton setTitle: @"下一步" forState: UIControlStateNormal];
    [nextStepButton.layer setCornerRadius: 3.0f];
    [nextStepButton.titleLabel setFont: [UIFont systemFontOfSize: 14.0f]];
    [nextStepButton setTag: 1];
    [nextStepButton addTarget:self action: @selector(stepButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    [mainScrollView addSubview: nextStepButton];
    
    ///18.调整滚动视图的contentSize
    CGFloat size_h = nextStepButton.frame.size.height + nextStepButton.frame.origin.y + 20.0f;
    size_h = (size_h > curScreenSize.height ? size_h : curScreenSize.height + 20.0f);
    [mainScrollView setContentSize: CGSizeMake(curScreenSize.width, size_h)];
}

#pragma mark -
#pragma mark 步骤按钮点击事件
- (void)stepButtonClick:(UIButton *)sender
{
    switch ([sender tag]) {
        case 0:
        {
            [self.navigationController popViewControllerAnimated: NO];
            break;
        }
        case 1:{
            PJStepSevenViewController *nextSteptVC = [[PJStepSevenViewController alloc] init];
            [self.navigationController pushViewController: nextSteptVC animated: NO];
            break;
        }
        default:
            break;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
