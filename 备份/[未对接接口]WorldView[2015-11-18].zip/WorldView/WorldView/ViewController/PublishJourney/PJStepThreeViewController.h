//
//  PJStepThreeViewController.h
//  WorldView
//
//  Created by XZJ on 11/6/15.
//  Copyright © 2015 XZJ. All rights reserved.
//

#import "BaseViewController.h"

@interface PJStepThreeViewController : BaseViewController<UITextViewDelegate>
{
    UIScrollView *mainScrollView;
    UIView *travelLineView;
    UIButton *addLocationbutton;
    NSMutableArray *travelLocationTextFiledArray;
    CGFloat baseLocationWidth;
    UIView *remarksView;
}
@end
