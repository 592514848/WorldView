//
//  ModelObject.h
//  WorldView
//
//  Created by WorldView on 15/11/16.
//  Copyright © 2015年 XZJ. All rights reserved.
//
#define INTERFACE_SUCEESS_RETURN_CODE 10000
#import <Foundation/Foundation.h>
#import "XZJ_CommonClass.h"

@interface ModelObject : NSObject<XZJ_AsyncRequestDataDelegate>
{
    XZJ_ApplicationClass *applicationClass;
    XZJ_AsyncRequestData *asyncRequestData;
}
@end
