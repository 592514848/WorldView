//
//  TravelListViewController.m
//  WorldView
//
//  Created by XZJ on 10/31/15.
//  Copyright © 2015 XZJ. All rights reserved.
//

#define PICKER_HEIGHT 45.0f
#define HEADER_HEIGHT 10.0F
#define CELL_HEIGHT 160.0F
#import "TravelListViewController.h"

@implementation TravelListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setTitle: @"我的行程单"];
    [self loadMainTableView];
    [self loadPickerView];
}

#pragma mark -
#pragma mark 加载筛选视图
- (void)loadPickerView
{
    ////1.筛选视图的主视图
    UIView *pickereView = [[UIView alloc] initWithFrame: CGRectMake(0.0f, 0.0f, curScreenSize.width, PICKER_HEIGHT)];
    [pickereView setBackgroundColor: [UIColor whiteColor]];
    [pickereView.layer setBorderColor: [applicationClass methodOfTurnToUIColor: @"#ea5357"].CGColor];
    [pickereView.layer setBorderWidth: 0.5f];
    [pickereView.layer setShadowOpacity: 0.2f];
    [pickereView.layer setShadowOffset: CGSizeMake(0.0f, 3.0f)];
    [self.view addSubview: pickereView];
    ////2.筛选按钮
    CGFloat size_w = curScreenSize.width / 2.0f;
    for(NSInteger i = 0; i < 2; i++)
    {
        UIButton *tempButton = [[UIButton alloc] initWithFrame: CGRectMake(i * size_w, 0.0f, size_w, PICKER_HEIGHT)];
        [tempButton setTitleColor: [applicationClass methodOfTurnToUIColor:@"#ea5357"] forState: UIControlStateNormal];
        [tempButton setTitleColor: [UIColor whiteColor] forState: UIControlStateSelected];
        if(i == 0){
            [tempButton setSelected: YES];
            lastSelectedButton = tempButton;
            [tempButton setTitle: @"未成行" forState: UIControlStateNormal];
            [tempButton setBackgroundColor: [applicationClass methodOfTurnToUIColor: @"#ea5357"]];
        }
        else{
            [tempButton setTitle: @"已成行" forState: UIControlStateNormal];
        }
        [tempButton setTag: i];
        [tempButton.titleLabel setFont: [UIFont boldSystemFontOfSize: 15.0f]];
        [tempButton addTarget: self action: @selector(pickerButtonClick:) forControlEvents: UIControlEventTouchUpInside];
        [pickereView addSubview: tempButton];
    }
}

#pragma mark -
#pragma mark 筛选按钮的点击事件
- (void)pickerButtonClick:(UIButton *)sender
{
    if(lastSelectedButton != sender){
        [sender setSelected: YES];
        [lastSelectedButton setSelected: NO];
        [lastSelectedButton setBackgroundColor: [UIColor whiteColor]];
        [sender setBackgroundColor: [applicationClass methodOfTurnToUIColor: @"#ea5357"]];
        lastSelectedButton = sender;
    }
    switch ([sender tag]) {
        case 0:
            break;
        default:
            break;
    }
}

#pragma mark -
#pragma mark 加载数据视图
- (void)loadMainTableView
{
    [self.view setBackgroundColor: [applicationClass methodOfTurnToUIColor: @"#f0f0f1"]];
    XZJ_EGOTableView *mainTableView = [[XZJ_EGOTableView alloc] initWithFrame: CGRectMake(0.0f, PICKER_HEIGHT, curScreenSize.width, curScreenSize.height - PICKER_HEIGHT)];
    [mainTableView setXDelegate: self];
    [mainTableView setTableViewFooterView];
//    [mainTableView.tableView setScrollEnabled: NO];
    [self.view addSubview: mainTableView];
    [mainTableView updateViewSize: CGSizeMake(mainTableView.frame.size.width, 5 * (HEADER_HEIGHT + CELL_HEIGHT)) showFooter: YES];
}

#pragma mark XZJ_EGOTableView委托
- (NSInteger)numberOfSectionsIn_XZJ_EGOTableView:(UITableView *)_tableView
{
    return 5;
}

- (NSInteger)XZJ_EGOTableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}

- (UITableViewCell *)XZJ_EGOTableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    TravelListTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier: @"ListCell"];
    if(!cell){
        cell = [[TravelListTableViewCell alloc] initWithStyle: UITableViewCellStyleDefault reuseIdentifier: @"ListCell" size: CGSizeMake(tableView.frame.size.width, CELL_HEIGHT)];
    }
    [cell setSelectionStyle: UITableViewCellSelectionStyleNone];
    switch ([indexPath section]) {
        case 0:
            [cell displayForStatus: @"已支付"];
            break;
        case 1:
            [cell displayForStatus: @"未支付"];
            break;
        case 2:
            [cell displayForStatus: @"过期"];
            break;
        case 3:
            [cell displayForStatus: @"未评价"];
            break;
        case 4:
            [cell displayForStatus: @"已评价"];
            break;
        default:
            break;
    }
    
    [cell setPhotoImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: @"photo" ofType: @"jpg"]] sex: @"男"];
    [cell.nameLabel setText: @"熊梓君"];
    [cell.titleLabel setText: @"漫步诗人，意大利的魅力"];
    [cell.subTitleLabel setText: @"感受意大利文化的积淀，走进不一样的世界;感受意大利文化的积淀，走进不一样的世界"];
    [cell.timeLabel setText: @"还剩：15天09小时"];
    [cell setPricelText: @"$210"];
    [cell setStarLevel: 3];
    return cell;
}

- (CGFloat)XZJ_EGOTableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return HEADER_HEIGHT;
}

- (CGFloat)XZJ_EGOTableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return CELL_HEIGHT;
}

- (UIView *)XZJ_EGOTableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *view = [[UIView alloc] init];
    [view setBackgroundColor: [UIColor clearColor]];
    return view;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
