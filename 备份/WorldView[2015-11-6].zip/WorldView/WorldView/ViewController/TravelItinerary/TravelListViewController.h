//
//  TravelListViewController.h
//  WorldView
//
//  Created by XZJ on 10/31/15.
//  Copyright © 2015 XZJ. All rights reserved.
//

#import "BaseViewController.h"
#import "TravelListTableViewCell.h"

@interface TravelListViewController : BaseViewController<XZJ_EGOTableViewDelegate>
{
    UIButton *lastSelectedButton;
}
@end
