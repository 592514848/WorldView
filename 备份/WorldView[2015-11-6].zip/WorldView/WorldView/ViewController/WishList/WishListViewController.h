//
//  WishListViewController.h
//  WorldView
//
//  Created by XZJ on 11/2/15.
//  Copyright © 2015 XZJ. All rights reserved.
//

#import "BaseViewController.h"

@interface WishListViewController : BaseViewController<XZJ_EGOTableViewDelegate>

@end
