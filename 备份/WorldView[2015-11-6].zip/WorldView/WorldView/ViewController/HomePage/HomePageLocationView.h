//
//  HomePageLocationView.h
//  WorldView
//
//  Created by XZJ on 10/30/15.
//  Copyright © 2015 XZJ. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol HomePageLocationViewDelegate <NSObject>
- (void)homePageLocationView_DidCancelButton;
@end

@interface HomePageLocationView : UIView<UITableViewDataSource, UITableViewDelegate>
{
    UIView *lineView;
    NSTimer *timer;
    UIView *contentView;
    id<HomePageLocationViewDelegate> xDelegate;
}
- (id)initWithFrame:(CGRect)frame buttonRect:(CGRect) buttonFrame delegate:(id<HomePageLocationViewDelegate>) _delegate;
@end
