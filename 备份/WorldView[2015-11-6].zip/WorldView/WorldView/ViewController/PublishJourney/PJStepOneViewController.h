//
//  PJStepOneViewController.h
//  WorldView
//
//  Created by XZJ on 11/4/15.
//  Copyright © 2015 XZJ. All rights reserved.
//

#import "BaseViewController.h"

@interface PJStepOneViewController : BaseViewController<UITextFieldDelegate,XZJ_CustomPicker_Delegate>
{
    UITextField *numberTextfiled;
    NSMutableArray *typeImageViewArray;
    NSInteger maxNumber; //最大人数限制
    XZJ_CustomPicker *mainPickerView;
    NSArray *pickerDataArray;
    UITextField *cityTextfiled;
}
@end
