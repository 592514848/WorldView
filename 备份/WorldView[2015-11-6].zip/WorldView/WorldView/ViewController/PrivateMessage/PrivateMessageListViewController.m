//
//  PrivateMessageListViewController.m
//  WorldView
//
//  Created by XZJ on 11/2/15.
//  Copyright © 2015 XZJ. All rights reserved.
//

#define HEADER_HEIGHT 10.0F
#define CELL_HEIGHT 120.0F
#import "PrivateMessageListViewController.h"
#import "PrivateMessageTableViewCell.h"
@implementation PrivateMessageListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setTitle: @"私信"];
    [self loadMainTableView];
}

- (void)loadMainTableView
{
    [self.view setBackgroundColor: [applicationClass methodOfTurnToUIColor: @"#eff0f1"]];
    XZJ_EGOTableView *mainTableView = [[XZJ_EGOTableView alloc] initWithFrame: CGRectMake(0.0f, 0.0f, curScreenSize.width, curScreenSize.height)];
    [mainTableView setXDelegate: self];
    [mainTableView setTableViewFooterView];
    [mainTableView setBackgroundColor: [applicationClass methodOfTurnToUIColor: @"#eff0f1"]];
    //    [mainTableView.tableView setScrollEnabled: NO];
    [self.view addSubview: mainTableView];
    [mainTableView updateViewSize: CGSizeMake(mainTableView.frame.size.width, 5 * (HEADER_HEIGHT + CELL_HEIGHT)) showFooter: YES];
}

#pragma mark XZJ_EGOTableView委托
- (NSInteger)numberOfSectionsIn_XZJ_EGOTableView:(UITableView *)_tableView
{
    return 5;
}

- (NSInteger)XZJ_EGOTableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}

- (UITableViewCell *)XZJ_EGOTableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    PrivateMessageTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier: @"ListCell"];
    if(!cell){
        cell = [[PrivateMessageTableViewCell alloc] initWithStyle: UITableViewCellStyleDefault reuseIdentifier: @"ListCell" size: CGSizeMake(tableView.frame.size.width, CELL_HEIGHT)];
    }
    [cell setSelectionStyle: UITableViewCellSelectionStyleNone];
    
    [cell setPhotoImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: @"photo" ofType: @"jpg"]] sex: @"男"];
    [cell.nameLabel setText: @"Kasha 莉莲"];
    [cell.titleLabel setText: @"遭受战争洗礼见证历史辉煌的光辉历史光辉历史"];
    [cell.timeLabel setText: @"刚刚"];
    [cell.contentLabel setText: @"您好，请问一下请问一下请问一下请问一下请问一下请问一下请问一下请问一下请问一下请问一下请问一下请问一下请问一下"];
    return cell;
}

- (CGFloat)XZJ_EGOTableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return HEADER_HEIGHT;
}

- (CGFloat)XZJ_EGOTableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return CELL_HEIGHT;
}

- (UIView *)XZJ_EGOTableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *view = [[UIView alloc] init];
    [view setBackgroundColor: [UIColor clearColor]];
    return view;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
