//
//  PublishedJourneyViewController.m
//  WorldView
//
//  Created by XZJ on 11/3/15.
//  Copyright © 2015 XZJ. All rights reserved.
//
#define PICKER_HEIGHT 45.0f
#define CELL_HEIGHT 295.0F
#import "PublishedJourneyViewController.h"
#import "PublishedJourneyTableViewCell.h"

@implementation PublishedJourneyViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setTitle: @"我发布的旅程"];
    [self loadMainTableView];
    [self loadPickerView];
}

#pragma mark -
#pragma mark 加载筛选视图
- (void)loadPickerView
{
    ////1.筛选视图的主视图
    UIView *pickereView = [[UIView alloc] initWithFrame: CGRectMake(0.0f, 0.0f, curScreenSize.width, PICKER_HEIGHT)];
    [pickereView setBackgroundColor: [UIColor whiteColor]];
    [pickereView.layer setBorderColor: [applicationClass methodOfTurnToUIColor: @"#ea5357"].CGColor];
    [pickereView.layer setBorderWidth: 0.5f];
    [pickereView.layer setShadowOpacity: 0.2f];
    [pickereView.layer setShadowOffset: CGSizeMake(0.0f, 3.0f)];
    [self.view addSubview: pickereView];
    ////2.筛选按钮
    CGFloat size_w = curScreenSize.width / 2.0f;
    for(NSInteger i = 0; i < 2; i++)
    {
        UIButton *tempButton = [[UIButton alloc] initWithFrame: CGRectMake(i * size_w, 0.0f, size_w, PICKER_HEIGHT)];
        [tempButton setTitleColor: [applicationClass methodOfTurnToUIColor:@"#ea5357"] forState: UIControlStateNormal];
        [tempButton setTitleColor: [UIColor whiteColor] forState: UIControlStateSelected];
        if(i == 0){
            [tempButton setSelected: YES];
            lastSelectedButton = tempButton;
            [tempButton setTitle: @"进行中" forState: UIControlStateNormal];
            [tempButton setBackgroundColor: [applicationClass methodOfTurnToUIColor: @"#ea5357"]];
        }
        else{
            [tempButton setTitle: @"已下架" forState: UIControlStateNormal];
        }
        [tempButton setTag: i];
        [tempButton.titleLabel setFont: [UIFont boldSystemFontOfSize: 15.0f]];
        [tempButton addTarget: self action: @selector(pickerButtonClick:) forControlEvents: UIControlEventTouchUpInside];
        [pickereView addSubview: tempButton];
    }
}

#pragma mark -
#pragma mark 筛选按钮的点击事件
- (void)pickerButtonClick:(UIButton *)sender
{
    if(lastSelectedButton != sender){
        [sender setSelected: YES];
        [lastSelectedButton setSelected: NO];
        [lastSelectedButton setBackgroundColor: [UIColor whiteColor]];
        [sender setBackgroundColor: [applicationClass methodOfTurnToUIColor: @"#ea5357"]];
        lastSelectedButton = sender;
    }
    switch ([sender tag]) {
        case 0:
            break;
        default:
            break;
    }
}

#pragma mark -
#pragma mark 加载数据视图
- (void)loadMainTableView
{
    [self.view setBackgroundColor: [applicationClass methodOfTurnToUIColor: @"#f0f0f1"]];
    XZJ_EGOTableView *mainTableView = [[XZJ_EGOTableView alloc] initWithFrame: CGRectMake(0.0f, PICKER_HEIGHT, curScreenSize.width, curScreenSize.height - PICKER_HEIGHT)];
    [mainTableView setXDelegate: self];
    [mainTableView setTableViewFooterView];
    [mainTableView setBackgroundColor: [applicationClass methodOfTurnToUIColor: @"#f0f0f1"]];
    [mainTableView setSeparatorStyle: UITableViewCellSeparatorStyleNone];
    [self.view addSubview: mainTableView];
    [mainTableView updateViewSize: CGSizeMake(mainTableView.frame.size.width, 3 * CELL_HEIGHT) showFooter: YES];
}

#pragma mark XZJ_EGOTableView委托
- (NSInteger)numberOfSectionsIn_XZJ_EGOTableView:(UITableView *)_tableView
{
    return 1;
}

- (NSInteger)XZJ_EGOTableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 3;
}

- (UITableViewCell *)XZJ_EGOTableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    PublishedJourneyTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier: @"ListCell"];
    if(!cell){
        cell = [[PublishedJourneyTableViewCell alloc] initWithStyle: UITableViewCellStyleDefault reuseIdentifier: @"ListCell" size: CGSizeMake(tableView.frame.size.width, CELL_HEIGHT)];
    }
    [cell setSelectionStyle: UITableViewCellSelectionStyleNone];
    NSString *status = ([indexPath row] % 2 == 0 ? @"已下架" : @"未下架");
    [cell displayForStatus: status];
    NSString *sex = ([indexPath row] % 2 == 0 ? @"男" : @"女");
    [cell setPhotoImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: @"photo" ofType: @"jpg"]] sex: sex];
    [cell.localImageView setImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: [NSString stringWithFormat: @"w%ld", (long)[indexPath row] % 2] ofType: @"png"]]];;
    [cell.nameLabel setText: @"by Muchle 曾玲玲"];
    [cell.titleLabel setText: @"我在小船等你，与你一起感受浪漫威尼斯"];
    [cell.appointNumberLabel setText: @"30人参与"];
    [cell.localLabel setText: @"意大利，威尼斯"];
    [cell setStarLevel: 3];
    [cell.collectionNumberLabel setText: @"510"];
    return cell;
}

- (CGFloat)XZJ_EGOTableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 0.0f;
}

- (CGFloat)XZJ_EGOTableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return CELL_HEIGHT;
}

- (UIView *)XZJ_EGOTableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *view = [[UIView alloc] init];
    [view setBackgroundColor: [UIColor clearColor]];
    return view;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
