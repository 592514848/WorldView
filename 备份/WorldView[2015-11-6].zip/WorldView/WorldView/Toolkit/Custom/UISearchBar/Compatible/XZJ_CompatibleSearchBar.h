//
//  XZJ_CompatibleSearchBar.h
//  GRDApplication
//
//  Created by XZJ on 15/1/10.
//  Copyright (c) 2015年 Xiong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XZJ_CompatibleSearchBar : UISearchBar
- (id)initWithFrame:(CGRect)frame withBackGroundColor:(UIColor *) _color;
@end
