//
//  XZJ_AsyncRequestData.m
//  XZJ_GetAsyncData
//
//  Created by 6602 on 13-12-9.
//  Copyright (c) 2013年 Xiong. All rights reserved.
//

#import "XZJ_AsyncRequestData.h"
#import "AFHTTPRequestOperationManager.h"
#import "AFHTTPSessionManager.h"
#import "jsonkit.h"

@implementation XZJ_AsyncRequestData
@synthesize delegate;

#pragma mark -
#pragma mark [XZJ_AsyncRequestData初始化函数]
- (id)init
{
    if(self = [super init])
    {
    }
    return self;
}

#pragma mark -
#pragma mark 版本2.0 (采用AFNetworking库实现同步、异步的GET、POST请求)
#pragma mark -
#pragma mark [XZJ_AsyncRequestData便利初始化函数]
- (id)initWithDelegate:(id<XZJ_AsyncRequestDataDelegate>) _delegate
{
    if(self = [super init])
    {
        delegate = _delegate;
    }
    return self;
}

#pragma mark -
#pragma mark 使用GET方式开始异步请求
/*!
 @method
 @abstract 使用GET方式开始异步请求
 @discussion 本方法通过XZJ_AsyncRequestData对象来调用本方法，注意_requestURL这个参数为NSString类型，不需要NSURL类型。
 @param _requestURL:调用接口的URL（NSString类型）。
 @param isShow:是否显示加载数据时的活动指示器。
 @result 无返回结果
 */
- (void)startAsyncRequestData_GET:(NSString *) _requestURL showIndicator:(BOOL) isShow
{
    [self startAsyncRequestData_GET: _requestURL contentType: @"text/plain" showIndicator: isShow isTip: YES isOuter: NO];
}

#pragma mark -
#pragma mark 使用GET方式开始异步请求
/*!
 @method
 @abstract 使用GET方式开始异步请求
 @discussion 本方法通过XZJ_AsyncRequestData对象来调用本方法，注意_requestURL这个参数为NSString类型，不需要NSURL类型。
 @param _requestURL:调用接口的URL（NSString类型）。
 @param isShow:是否显示加载数据时的活动指示器。
 @param isTip:是否显示错误提示。
 @result 无返回结果
 */
- (void)startAsyncRequestData_GET:(NSString *) _requestURL showIndicator:(BOOL) isShow isTip:(BOOL) isTip
{
    [self startAsyncRequestData_GET: _requestURL contentType: @"text/plain" showIndicator: isShow isTip: isTip isOuter: NO];
}

- (void)startAsyncRequestData_GET:(NSString *) _requestURL showIndicator:(BOOL) isShow isOuter:(BOOL) isOuter
{
    [self startAsyncRequestData_GET: _requestURL contentType: @"text/plain" showIndicator: isShow isTip: YES isOuter: isOuter];
}

#pragma mark -
#pragma mark 使用GET方式开始异步请求
/*!
 @method
 @abstract 使用GET方式开始异步请求
 @discussion 本方法通过XZJ_AsyncRequestData对象来调用本方法，注意_requestURL这个参数为NSString类型，不需要NSURL类型。
 @param _requestURL:调用接口的URL（NSString类型）。
 @param contentType:请求数据时的content-Type:("text/javascript";"text/plain"....)。
 @param isShow:是否显示加载数据时的活动指示器。
 @result 无返回结果
 */
- (void)startAsyncRequestData_GET:(NSString *) _requestURL contentType:(NSString *) _contentType showIndicator:(BOOL) isShow isTip:(BOOL) isTip isOuter:(BOOL) isOuter
{
    [[(UIViewController *)delegate view] setUserInteractionEnabled: NO];
    if(isShow)
    {
        [[XZJ_ApplicationClass commonApplication] showActivityIndicatorView];
    }
    AFHTTPRequestOperationManager *operateManager = [AFHTTPRequestOperationManager manager];
    [operateManager.responseSerializer setAcceptableContentTypes:[NSSet setWithObject: _contentType]];
    [operateManager GET: _requestURL parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
       [[XZJ_ApplicationClass commonApplication] hiddenActivityIndicatorView];
        if(isOuter)
        {
            if([delegate respondsToSelector: @selector(XZJ_AsyncRequestDataReceiveData:)])
                [delegate XZJ_AsyncRequestDataReceiveData: responseObject];
        }
        else
        {
            if([[responseObject objectForKey: @"result"] isEqualToString: @"0x00"])
            {
                if([delegate respondsToSelector: @selector(XZJ_AsyncRequestDataReceiveData:)])
                    [delegate XZJ_AsyncRequestDataReceiveData: responseObject];
            }
            else
                [[XZJ_ApplicationClass commonApplication] methodOfShowAlert: @"数据请求错误,请稍后再试"];
        }
        [[(UIViewController *)delegate view] setUserInteractionEnabled: YES];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        if(isTip)
        {
            [[XZJ_ApplicationClass commonApplication] hiddenActivityIndicatorView];
            [[(UIViewController *)delegate view] setUserInteractionEnabled: YES];
            [[XZJ_ApplicationClass commonApplication] methodOfShowAlert: @"网络开小差，请稍后再试"];
        }
    }];
}

#pragma mark -
#pragma mark 使用GET方式开始同步请求
/*!
 @method
 @abstract 使用GET方式开始同步请求
 @discussion 本方法通过XZJ_AsyncRequestData对象来调用本方法，注意_requestURL这个参数为NSString类型，不需要NSURL类型。
 @param _requestURL:调用接口的URL（NSString类型）。
 @param isShow:是否显示加载数据时的活动指示器。
 @result 返回的是将从服务器上获取的数据转成的NSDictioanry类型的数据
 */
- (NSDictionary *)startSyncRequestData_GET:(NSString *) _requestURL showIndicator:(BOOL) isShow
{
    if(isShow)
    {
        [[XZJ_ApplicationClass commonApplication] showActivityIndicatorView];
    }
    NSMutableURLRequest *synchronousRequest = [[NSMutableURLRequest alloc] initWithURL: [NSURL URLWithString: _requestURL]];
    [synchronousRequest setHTTPMethod: @"GET"];
    NSError *error;
    NSData *returnData = [NSURLConnection sendSynchronousRequest: synchronousRequest returningResponse:nil error:&error];
    if(!error)
    {
        NSString *responsedString = [[NSString alloc] initWithData: returnData encoding:NSUTF8StringEncoding];
        responsedString = [responsedString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        NSDictionary *responesedDictionary = [responsedString objectFromJSONStringWithParseOptions: JKParseOptionLooseUnicode];
        [[XZJ_ApplicationClass commonApplication] hiddenActivityIndicatorView];
        if([[responesedDictionary objectForKey: @"result"] isEqualToString: @"0x00"])
        {
            return responesedDictionary;
        }
        else
        {
            [[XZJ_ApplicationClass commonApplication] methodOfShowAlert: @"服务器异常，是否退出程序？"];
            return nil;
        }
    }
    else
    {
        NSLog(@"%@", [error description]);
        return nil;
    }
}

#pragma mark -
#pragma mark 使用POST方式开始异步请求
/*!
 @method
 @abstract 使用POST方式开始异步请求
 @discussion 本方法通过XZJ_AsyncRequestData对象来调用本方法，注意_requestURL这个参数为NSString类型，不需要NSURL类型。
 @param _requestURL:调用接口的URL（NSString类型）。
 @param _param:需要上传的数据。
 @param isShow:是否显示加载数据时的活动指示器。
 @result 无返回结果
 */
- (void)startAsyncRequestData_POST:(NSString *) _requestURL param:(NSString *) _param showIndicator:(BOOL) isShow
{
    if(isShow)
    {
        [[XZJ_ApplicationClass commonApplication] showActivityIndicatorView];
    }
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL: [NSURL URLWithString: _requestURL]];
    [request setTimeoutInterval:10.0f];
    [request setHTTPMethod:@"POST"];
    [request setValue: [NSString stringWithFormat: @"%ld", (long)[_param length]] forHTTPHeaderField:@"Content-Length"];
    [request setValue: @"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    NSData *httpData = [_param dataUsingEncoding: NSUTF8StringEncoding];
    [request setHTTPBody: httpData];
    
    AFHTTPRequestOperation *operation =[[AFHTTPRequestOperation alloc]initWithRequest:request];
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
     {
         [[XZJ_ApplicationClass commonApplication] hiddenActivityIndicatorView];
         NSString *responsedString = [[NSString alloc] initWithData: responseObject encoding:NSUTF8StringEncoding];
         responsedString = [responsedString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
         NSDictionary *responesedDictionary = [responsedString objectFromJSONStringWithParseOptions: JKParseOptionLooseUnicode];
         if([[responesedDictionary objectForKey: @"result"] isEqualToString: @"0x00"])
         {
             if([delegate respondsToSelector: @selector(XZJ_AsyncRequestDataReceiveData:)])
                 [delegate XZJ_AsyncRequestDataReceiveData:responesedDictionary];
         }
         else
         {
             UIAlertView *alertView = [[UIAlertView alloc] initWithTitle: @"温馨提示" message: @"网络开小差，请稍后再试" delegate: nil cancelButtonTitle: @"确定" otherButtonTitles: nil];
             [alertView show];
         }
     } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
         [[XZJ_ApplicationClass commonApplication] hiddenActivityIndicatorView];
         UIAlertView *alertView = [[UIAlertView alloc] initWithTitle: @"温馨提示" message: @"网络开小差，请稍后再试" delegate: nil cancelButtonTitle: @"确定" otherButtonTitles: nil];
         [alertView show];
     }];
    [operation start];
}

#pragma mark -
#pragma mark 使用POST方式开始同步请求
/*!
 @method
 @abstract 使用POST方式开始异步请求
 @discussion 本方法通过XZJ_AsyncRequestData对象来调用本方法，注意_requestURL这个参数为NSString类型，不需要NSURL类型。
 @param _requestURL:调用接口的URL（NSString类型）。
 @param _param:需要上传的数据。
 @param isShow:是否显示加载数据时的活动指示器。
 @result 无返回结果
 */
- (NSDictionary *)startSyncRequestData_POST:(NSString *) _requestURL param:(NSString *) _param showIndicator:(BOOL) isShow
{
    if(isShow)
    {
        [[XZJ_ApplicationClass commonApplication] showActivityIndicatorView];
    }
    
    NSURL *url = [NSURL URLWithString: _requestURL];
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc]initWithURL:url cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:10];
    [request setHTTPMethod:@"POST"];//设置请求方式为POST，默认为GET
    NSData *httpData = [_param dataUsingEncoding: NSUTF8StringEncoding];
    [request setHTTPBody: httpData];
    NSData *receivedString = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];

    //对数据进行处理
   [[XZJ_ApplicationClass commonApplication] hiddenActivityIndicatorView];
    NSString *responsedString = [[NSString alloc] initWithData: receivedString encoding:NSUTF8StringEncoding];
    responsedString = [responsedString stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSDictionary *responesedDictionary = [responsedString objectFromJSONStringWithParseOptions: JKParseOptionLooseUnicode];
    if([[responesedDictionary objectForKey: @"result"] isEqualToString: @"0x00"])
    {
        return responesedDictionary;
    }
    else
    {
        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle: @"温馨提示" message: @"网络开小差，请稍后再试" delegate: nil cancelButtonTitle: @"确定" otherButtonTitles: nil];
        [alertView show];
        return nil;
    }
}

#pragma mark -
#pragma mark 发起上传图片的异步请求
/*!
 @method
 @abstract 发起上传图片的异步请求
 @discussion 本方法通过XZJ_AsyncRequestData对象来调用本方法，注意_requestURL这个参数为NSString类型，不需要NSURL类型。
 @param _requestURL:调用接口的URL（NSString类型）。
 @param imageData: 是需要上传的图片（需要将图片装换成NSData类型）。
 @param isShow:是否显示加载数据时的活动指示器。
 @result 无返回结果
 */
- (void)startAsyncUploadImageWithURL:(NSString *) _requestURL imageData:(NSData *) imageData showIndicator:(BOOL) isShow
{
    if(isShow)
    {
        [[XZJ_ApplicationClass commonApplication] showActivityIndicatorView];
    }
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL: [NSURL URLWithString: _requestURL]];
    [request setTimeoutInterval:10.f];
    [request setHTTPMethod:@"POST"];
    [request setValue:@"binary/octet-stream" forHTTPHeaderField:@"Content-Type"];
    [request setValue: [NSString stringWithFormat: @"%lu",(unsigned long)[imageData length]] forHTTPHeaderField:@"Content-Length"];
    [request setHTTPBody: imageData];
    AFHTTPRequestOperation *operation =[[AFHTTPRequestOperation alloc]initWithRequest:request];
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
     {
         [[XZJ_ApplicationClass commonApplication] hiddenActivityIndicatorView];
         if([delegate respondsToSelector: @selector(XZJ_AsyncRequestDataUploadFinished:)])
             [delegate XZJ_AsyncRequestDataUploadFinished:YES];
     } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
         //NSLog(@"Failure: %@", error);
     }];
    [operation start];
}
@end
