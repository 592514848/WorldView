//
//  ReserveListTableViewCell.h
//  WorldView
//
//  Created by XZJ on 11/2/15.
//  Copyright © 2015 XZJ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XZJ_ApplicationClass.h"

@interface ReserveListTableViewCell : UITableViewCell
{
    XZJ_ApplicationClass *applicationClass;
    UIImageView *photoImageView;
    UIButton *operateButton;
    UIButton *rejectButton;
}
@property(nonatomic, retain) XZJ_CustomLabel *nameLabel;
@property(nonatomic, retain) XZJ_CustomLabel *titleLabel;
@property(nonatomic, retain) XZJ_CustomLabel *timeLabel;
@property(nonatomic, retain) XZJ_CustomLabel *placeLabel;
@property(nonatomic, retain) XZJ_CustomLabel *numberLabel;
@property(nonatomic, retain) XZJ_CustomLabel *contentLabel;
@property(nonatomic, retain) XZJ_CustomLabel *timeSpanLabel;

- (id)initWithStyle:(UITableViewCellStyle) style reuseIdentifier:(NSString *) reuseIdentifier size:(CGSize) _size;
- (void)displayForStatus:(NSString *)status;
- (void)setPhotoImage:(UIImage *) image sex:(NSString *) _sex;
@end
