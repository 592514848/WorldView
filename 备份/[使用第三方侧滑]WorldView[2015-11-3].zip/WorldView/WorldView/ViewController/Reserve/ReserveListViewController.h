//
//  ReserveListViewController.h
//  WorldView
//
//  Created by XZJ on 11/2/15.
//  Copyright © 2015 XZJ. All rights reserved.
//

#import "BaseViewController.h"

@interface ReserveListViewController : BaseViewController<XZJ_EGOTableViewDelegate>
{
    UIButton *lastSelectedButton;
}
@end
