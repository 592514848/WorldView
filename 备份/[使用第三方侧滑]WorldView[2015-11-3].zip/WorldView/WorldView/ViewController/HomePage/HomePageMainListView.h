//
//  HomePageMainListView.h
//  WorldView
//
//  Created by XZJ on 11/3/15.
//  Copyright © 2015 XZJ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XZJ_ApplicationClass.h"

@interface HomePageMainListView : UIView<XZJ_EGOTableViewDelegate>
{
    XZJ_EGOTableView *mainTableView;
}
@property(nonatomic, retain) UIViewController *viewControllerSender;
- (id)initWithFrame:(CGRect)frame dataCount:(NSInteger) dataCount;
- (void)updateFrame:(CGRect) frame;
@end
