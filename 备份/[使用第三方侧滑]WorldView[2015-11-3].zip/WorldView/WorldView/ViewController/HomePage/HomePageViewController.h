//
//  HomePageViewController.h
//  WorldView
//
//  Created by XZJ on 10/28/15.
//  Copyright © 2015 XZJ. All rights reserved.
//

#import "BaseViewController.h"
#import "HomePageLoginView.h"
#import "HomePageNewsView.h"
#import "HomePageLocationView.h"
#import "HomePageMemberView.h"
#import "HomePageMainListView.h"

@interface HomePageViewController : BaseViewController<CDRTranslucentSideBarDelegate, HomePageLocationViewDelegate, HomePageNewsViewDelegate, HomePageMemberViewDelegate>
{
    CDRTranslucentSideBar *sideBar;
    CGFloat siderBarBackroundAplha;
    NSTimer *timer;
    UIButton *navigationRightButton;
    UIButton *navigationLeftButton;
    BOOL isPushNextVC;
    NSIndexPath *curOperateIndexPath;
    HomePageMainListView *homePageMainView;
}
@end
