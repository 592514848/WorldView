//
//  HomePageNewsView.m
//  WorldView
//
//  Created by XZJ on 10/30/15.
//  Copyright © 2015 XZJ. All rights reserved.
//
#define LINE_HEIGHT 60.0f
#import "HomePageNewsView.h"

@implementation HomePageNewsView
- (id)initWithFrame:(CGRect)frame buttonRect:(CGRect) buttonFrame delegate:(id<HomePageNewsViewDelegate>) _delegate
{
    if(self = [super initWithFrame: frame])
    {
        xDelegate = _delegate;
        [self setBackgroundColor: [[UIColor alloc] initWithWhite: 0.3f alpha: 0.6f]];
        ///1.取消按钮
        CGFloat flow = ([UIScreen mainScreen].bounds.size.width > 375.0f ? 20.0f : 16.0f);
        UIButton *cancelButton = [[UIButton alloc] initWithFrame: CGRectMake(buttonFrame.origin.x + flow, 20.0f + buttonFrame.origin.y, buttonFrame.size.width, buttonFrame.size.height)];
        [cancelButton setImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: @"cancel_btn" ofType: @"png"]] forState: UIControlStateNormal];
        [cancelButton setContentMode: UIViewContentModeScaleAspectFit];
        [cancelButton setImageEdgeInsets: UIEdgeInsetsMake(12.0f, 12.0f, 12.0f, 12.0f)];
        [cancelButton addTarget: self action: @selector(cancelButtonClick) forControlEvents: UIControlEventTouchUpInside];
        [self addSubview: cancelButton];
        ///2.线条
        CGFloat origin_X = buttonFrame.size.width / 2.0f + buttonFrame.origin.x + flow - 1.0f;
        CGFloat origin_y = buttonFrame.size.height + cancelButton.frame.origin.y - 12.0f;
        lineView = [[UIView alloc] initWithFrame: CGRectMake(origin_X, origin_y, 1.0f, 1.0f)];
        [lineView setBackgroundColor: [UIColor whiteColor]];
        [self addSubview: lineView];
        //自动延长
        timer = [NSTimer scheduledTimerWithTimeInterval: 0.01f target: self selector: @selector(autoProlong) userInfo: nil repeats: YES];
        ///3.内容展示框
        origin_y += LINE_HEIGHT + 2.0f;
        origin_X = flow + 15.0f;
        contentView = [[UIView alloc] initWithFrame: CGRectMake(origin_X, origin_y, frame.size.width - 2 * origin_X, frame.size.height * 2.0f / 3.0f)];
        [contentView setBackgroundColor: [UIColor whiteColor]];
        [contentView.layer setCornerRadius: 3.0f];
        [contentView.layer setMasksToBounds: YES];
        [contentView setHidden: YES];
        [contentView.layer setMasksToBounds: YES];
        [self addSubview: contentView];
        ///4.内容的主题图片
        contentImageView = [[UIImageView alloc] initWithFrame: CGRectMake(0.0f, 0.0f, contentView.frame.size.width, contentView.frame.size.height)];
        [contentImageView setContentMode: UIViewContentModeScaleAspectFill];
        [contentImageView setImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: @"ad" ofType: @"png"]]];
        [contentImageView.layer setMasksToBounds: YES];
        [contentView addSubview: contentImageView];
    }
    return self;
}

#pragma mark -
#pragma mark 取消按钮
- (void)cancelButtonClick
{
    [contentView setHidden: YES];
    timer = [NSTimer scheduledTimerWithTimeInterval: 0.01f target: self selector: @selector(autoShorten) userInfo: nil repeats: YES];
}

#pragma mark 自动延长
- (void)autoProlong
{
    CGRect frame = [lineView frame];
    if(frame.size.height < LINE_HEIGHT){
        frame.size.height += 5.0f;
        [lineView setFrame: frame];
    }
    else
    {
        [timer setFireDate: [NSDate distantFuture]];
        [contentView setHidden: NO];
    }
}

#pragma mark 自动缩短
- (void)autoShorten
{
    CGRect frame = [lineView frame];
    frame.size.height -= 5.0f;
    if(frame.size.height > 0.0f){
        [lineView setFrame: frame];
    }
    else
    {
        [self setHidden: YES];
        if([xDelegate respondsToSelector: @selector(homePageNewsView_DidCancelButton)])
        {
            [xDelegate homePageNewsView_DidCancelButton];
        }
        [timer setFireDate: [NSDate distantFuture]];
    }
}
@end
