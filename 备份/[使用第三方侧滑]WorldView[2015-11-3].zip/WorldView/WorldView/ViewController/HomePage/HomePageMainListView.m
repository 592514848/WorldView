//
//  HomePageMainListView.m
//  WorldView
//
//  Created by XZJ on 11/3/15.
//  Copyright © 2015 XZJ. All rights reserved.
//
#define CELL_HEIGHT 240.0f
#import "HomePageMainListView.h"
#import "HomePageMainTableViewCell.h"
#import "TravelGroupViewController.h"

@implementation HomePageMainListView
@synthesize viewControllerSender;
- (id)initWithFrame:(CGRect)frame dataCount:(NSInteger) dataCount
{
    if(self = [super initWithFrame: frame])
    {
        [self setBackgroundColor: [UIColor clearColor]];
        ///tableVeiw
        mainTableView = [[XZJ_EGOTableView alloc] initWithFrame: frame];
        [mainTableView setXDelegate: self];
        [mainTableView setTableViewFooterView];
        [mainTableView setSeparatorStyle: UITableViewCellSeparatorStyleNone];
        [self addSubview: mainTableView];
        [mainTableView updateViewSize: CGSizeMake(mainTableView.frame.size.width, dataCount * CELL_HEIGHT) showFooter: YES];
    }
    return self;
}

- (void)updateFrame:(CGRect)frame
{
    [self setFrame: frame];
    [mainTableView setFrame: frame];
}

#pragma mark XZJ_EGOTableView委托
- (NSInteger)numberOfSectionsIn_XZJ_EGOTableView:(UITableView *)_tableView
{
    return 1;
}

- (NSInteger)XZJ_EGOTableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 5;
}

- (UITableViewCell *)XZJ_EGOTableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    HomePageMainTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier: @"ListCell"];
    if(!cell){
        cell = [[HomePageMainTableViewCell alloc] initWithStyle: UITableViewCellStyleDefault reuseIdentifier: @"ListCell" size: CGSizeMake(tableView.frame.size.width, CELL_HEIGHT)];
    }
    [cell setSelectionStyle: UITableViewCellSelectionStyleNone];
    [cell.mainImageView setImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: [NSString stringWithFormat: @"hp%ld", (long)indexPath.row] ofType: @"png"]]];
    [cell.ch_localNameLabel setText: @"意大利"];
    [cell.en_localNameLabel setText: @"Italy"];
    return cell;
}

- (CGFloat)XZJ_EGOTableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 0.0f;
}

- (CGFloat)XZJ_EGOTableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return CELL_HEIGHT;
}

- (void)XZJ_EGOTableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    TravelGroupViewController *nextVC = [[TravelGroupViewController alloc] init];
    [nextVC setTopBarTitle: @"意大利"];
    [viewControllerSender.navigationController pushViewController: nextVC animated: YES];
}
@end
