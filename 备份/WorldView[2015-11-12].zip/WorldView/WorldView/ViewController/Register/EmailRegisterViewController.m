//
//  EmailRegisterViewController.m
//  WorldView
//
//  Created by XZJ on 10/29/15.
//  Copyright © 2015 XZJ. All rights reserved.
//
#define BASE_HEIGHT 50.0f
#import "EmailRegisterViewController.h"
#import "PhoneRegisterViewController.h"

@implementation EmailRegisterViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self loadMainView];
}

- (void)loadMainView
{
    ///1.主视图
    [self.view setBackgroundColor: [applicationClass methodOfTurnToUIColor: @"#f0f0f0"]];
    UIView *mainView = [[UIView alloc] initWithFrame: CGRectMake(15.0f, self.point_y + 20.0f, curScreenSize.width - 30.0f, 2 * BASE_HEIGHT + 1.0f)];
    [mainView.layer setShadowOpacity: 0.15f];
    [mainView.layer setShadowOffset: CGSizeMake(0.0f, 3.0f)];
    [mainView setBackgroundColor: [UIColor whiteColor]];
    [self.view addSubview: mainView];
    ///2.输入框
    for(NSInteger i = 0; i < 2; i++){
        UITextField *tempTextField = [[UITextField alloc] initWithFrame: CGRectMake(10.0f, i * (BASE_HEIGHT + 1.0f), mainView.frame.size.width - 20.0f, BASE_HEIGHT)];
        [tempTextField setBackgroundColor: [UIColor clearColor]];
        [tempTextField setFont: [UIFont systemFontOfSize: 15.0f]];
        [tempTextField setDelegate: self];
        [tempTextField setKeyboardType: UIKeyboardTypeAlphabet];
        [mainView addSubview: tempTextField];
        switch (i) {
            case 0:{
                UIView *linView = [[UIView alloc] initWithFrame: CGRectMake(10.0f, BASE_HEIGHT, mainView.frame.size.width - 20.0f, 1.0f)];
                [linView setBackgroundColor: [applicationClass methodOfTurnToUIColor: @"#e5e5e5"]];
                [mainView addSubview: linView];
                [tempTextField setPlaceholder: @"电子邮箱"];
                break;
            }
            case 1:
                [tempTextField setPlaceholder: @"密码"];
                [tempTextField setSecureTextEntry: YES];
                break;
            default:
                break;
        }
        [mainView addSubview: tempTextField];
    }
    ///3.手机号注册
    CGFloat origin_y = mainView.frame.size.height + mainView.frame.origin.y + 10.0f;
    XZJ_CustomLabel * registerLabel = [[XZJ_CustomLabel alloc] initWithFrame: CGRectMake(15.0f, origin_y, curScreenSize.width - 35.0f, 30.0f)];
    NSMutableAttributedString *attributeString = [[NSMutableAttributedString alloc] initWithString: @"通过手机号注册"];
    NSRange contentRange = {0, [attributeString length]};
    [attributeString addAttribute: NSUnderlineStyleAttributeName value: [NSNumber numberWithInteger: NSUnderlineStyleSingle] range: contentRange];
    [registerLabel setAttributedText: attributeString];
    [registerLabel setTextAlignment: NSTextAlignmentRight];
    [registerLabel setFont: [UIFont systemFontOfSize: 14.0f]];
    [registerLabel setTextColor: [applicationClass methodOfTurnToUIColor: @"#0093fb"]];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget: self action: @selector(phoneRegisterClick)];
    [registerLabel addGestureRecognizer: tap];
    [registerLabel setUserInteractionEnabled: YES];
    [self.view addSubview: registerLabel];
    ///4.登录
    origin_y += registerLabel.frame.size.height + 10.0f;
    UIButton *registerButton = [[UIButton alloc] initWithFrame: CGRectMake(18.0f, origin_y, curScreenSize.width - 36.0f, BASE_HEIGHT)];
    [registerButton setTitle: @"注册" forState: UIControlStateNormal];
    [registerButton setTitleColor: [applicationClass methodOfTurnToUIColor: @"#ef6b6d"] forState: UIControlStateNormal];
    [registerButton.layer setBorderColor: [applicationClass methodOfTurnToUIColor: @"#ef6b6d"].CGColor];
    [registerButton setBackgroundColor: [UIColor clearColor]];
    [registerButton.layer setBorderWidth: 1.0f];
    [registerButton.layer setCornerRadius: 4.0f];
    [self.view addSubview: registerButton];
    ///5.选择注册协议
    origin_y += registerButton.frame.size.height + 20.0f;
    UIButton *checkbutton = [[UIButton alloc] initWithFrame: CGRectMake(curScreenSize.width / 4.0f, origin_y, BASE_HEIGHT / 2.0f, BASE_HEIGHT / 2.0f)];
    [checkbutton setImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: @"selection_none" ofType: @"png"]] forState: UIControlStateNormal];
    [checkbutton setImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: @"selection_checked" ofType: @"png"]] forState: UIControlStateSelected];
    [checkbutton addTarget: self action: @selector(checkButtonClick:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview: checkbutton];
    ///6.查看注册协议
    CGFloat origin_x = checkbutton.frame.size.width + checkbutton.frame.origin.x;
    XZJ_CustomLabel *protocolLabel = [[XZJ_CustomLabel alloc] initWithFrame: CGRectMake(origin_x, origin_y, curScreenSize.width / 2.0f, BASE_HEIGHT / 2.0f)];
    attributeString = [[NSMutableAttributedString alloc] initWithString: @"我 已 阅 读 并 同 意 用 户 协 议"];
    [attributeString addAttribute: NSForegroundColorAttributeName value: [applicationClass methodOfTurnToUIColor: @"#8f8f8f"] range: NSMakeRange(0, 14)];
    [attributeString addAttribute: NSForegroundColorAttributeName value: [applicationClass methodOfTurnToUIColor: @"#0093fb"] range: NSMakeRange(14, 7)];
    [protocolLabel setAttributedText: attributeString];
    [protocolLabel setFont: [UIFont systemFontOfSize: 13.0f]];
    [protocolLabel setTextAlignment: NSTextAlignmentCenter];
    [self.view addSubview: protocolLabel];
}

#pragma mark -
#pragma mark textfiled委托
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    responserTextFiled = textField;
}

#pragma mark -
#pragma mark 空白处点击事件
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [responserTextFiled resignFirstResponder];
}

#pragma mark -
#pragma mark 注册协议选择按钮
- (void)checkButtonClick:(UIButton *)sender
{
    [sender setSelected: ![sender isSelected]];
}


#pragma mark -
#pragma mark 手机注册
- (void)phoneRegisterClick
{
    PhoneRegisterViewController *phoneRegisterVC = [[PhoneRegisterViewController alloc] init];
    [phoneRegisterVC setXZJ_ControlMask: kMODALControlMask];
    [phoneRegisterVC setTopBarTitle: @"手机注册"];
    [self presentViewController: phoneRegisterVC animated: YES completion: nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
