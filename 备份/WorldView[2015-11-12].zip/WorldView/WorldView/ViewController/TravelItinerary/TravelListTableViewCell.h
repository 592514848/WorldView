//
//  TravelListTableViewCell.h
//  WorldView
//
//  Created by XZJ on 10/31/15.
//  Copyright © 2015 XZJ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XZJ_ApplicationClass.h"

@interface TravelListTableViewCell : UITableViewCell
{
    XZJ_ApplicationClass *applicationClass;
    UIImageView *statusImageView;
    UIImageView *photoImageView;
    NSMutableArray *starImageViewArray;
    UIButton *operateButton;
    UIView *starDisplayView;
}
@property(nonatomic, retain) XZJ_CustomLabel *nameLabel;
@property(nonatomic, retain) XZJ_CustomLabel *titleLabel;
@property(nonatomic, retain) XZJ_CustomLabel *subTitleLabel;
@property(nonatomic, retain) XZJ_CustomLabel *timeLabel;
@property(nonatomic, retain) XZJ_CustomLabel *priceLabel;

- (id)initWithStyle:(UITableViewCellStyle) style reuseIdentifier:(NSString *) reuseIdentifier size:(CGSize) _size;
- (void)displayForStatus:(NSString *)status;
- (void)setPhotoImage:(UIImage *) image sex:(NSString *) _sex;
- (void)setStarLevel:(NSInteger)level;
- (void)setPricelText:(NSString *)price;
@end
