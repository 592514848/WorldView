//
//  TravelGroupViewController.h
//  WorldView
//
//  Created by XZJ on 11/3/15.
//  Copyright © 2015 XZJ. All rights reserved.
//

#import "BaseViewController.h"

@interface TravelGroupViewController : BaseViewController<XZJ_EGOTableViewDelegate, UIScrollViewDelegate>
{
    UIScrollView *mainScrollView;
    XZJ_EGOTableView *mainTableView;
    UIButton *lastSelectedButton;
    UIView *pickereView;
    BOOL isAdjustView; //是否调整视图
}
@end
