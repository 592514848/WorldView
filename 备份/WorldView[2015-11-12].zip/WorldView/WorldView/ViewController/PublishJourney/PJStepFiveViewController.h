//
//  PJStepFiveViewController.h
//  WorldView
//
//  Created by XZJ on 11/6/15.
//  Copyright © 2015 XZJ. All rights reserved.
//

#import "BaseViewController.h"

@interface PJStepFiveViewController : BaseViewController<UITextViewDelegate>
{
    XZJ_CustomLabel *fontNumberLabel;
    NSString *textViewText;
}
@end
