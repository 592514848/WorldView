//
//  HomePageNewsView.h
//  WorldView
//
//  Created by XZJ on 10/30/15.
//  Copyright © 2015 XZJ. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol HomePageNewsViewDelegate <NSObject>
- (void)homePageNewsView_DidCancelButton;
@end

@interface HomePageNewsView : UIView
{
    UIView *lineView;
    NSTimer *timer;
    UIView *contentView;
    UIImageView *contentImageView;
     id<HomePageNewsViewDelegate> xDelegate;
}
- (id)initWithFrame:(CGRect)frame buttonRect:(CGRect) buttonFrame delegate:(id<HomePageNewsViewDelegate>) _delegate;
@end
