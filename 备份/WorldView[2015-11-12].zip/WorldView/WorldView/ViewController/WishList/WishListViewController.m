//
//  WishListViewController.m
//  WorldView
//
//  Created by XZJ on 11/2/15.
//  Copyright © 2015 XZJ. All rights reserved.
//
#define CELL_HEIGHT 300.0F
#import "WishListViewController.h"
#import "WishListTableViewCell.h"

@implementation WishListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setTitle: @"我的心愿单"];
    [self loadMainTableView];
}

- (void)loadMainTableView
{
    [self.view setBackgroundColor: [applicationClass methodOfTurnToUIColor: @"#eff0f1"]];
    XZJ_EGOTableView *mainTableView = [[XZJ_EGOTableView alloc] initWithFrame: CGRectMake(0.0f, 0.0f, curScreenSize.width, curScreenSize.height)];
    [mainTableView setXDelegate: self];
    [mainTableView setTableViewFooterView];
    [mainTableView setSeparatorStyle: UITableViewCellSeparatorStyleNone];
    [mainTableView setBackgroundColor: [applicationClass methodOfTurnToUIColor: @"#eff0f1"]];
    [self.view addSubview: mainTableView];
    [mainTableView updateViewSize: CGSizeMake(mainTableView.frame.size.width, 3 * CELL_HEIGHT) showFooter: YES];
}

#pragma mark XZJ_EGOTableView委托
- (NSInteger)numberOfSectionsIn_XZJ_EGOTableView:(UITableView *)_tableView
{
    return 1;
}

- (NSInteger)XZJ_EGOTableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 3;
}

- (UITableViewCell *)XZJ_EGOTableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    WishListTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier: @"ListCell"];
    if(!cell){
        cell = [[WishListTableViewCell alloc] initWithStyle: UITableViewCellStyleDefault reuseIdentifier: @"ListCell" size: CGSizeMake(tableView.frame.size.width, CELL_HEIGHT)];
    }
    [cell setSelectionStyle: UITableViewCellSelectionStyleNone];
    NSString *sex = ([indexPath row] % 2 == 0 ? @"男" : @"女");
    [cell setPhotoImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: @"photo" ofType: @"jpg"]] sex: sex];
    [cell setAppointButtonThemeColorBySex: sex];
    [cell.localImageView setImage: [UIImage imageWithContentsOfFile: [[NSBundle mainBundle] pathForResource: [NSString stringWithFormat: @"w%ld", (long)[indexPath row] % 2] ofType: @"png"]]];;
    [cell.nameLabel setText: @"by jonh 小博"];
    [cell.titleLabel setText: @"带你领略镜头下的圣母百花大教堂"];
    [cell.subTitleLabel setText: @"自由职业，摄影爱好者"];
    [cell setPricelText: @"$ 210"];
    [cell.appointNumberLabel setText: @"30人参与"];
    [cell.localLabel setText: @"荷兰，阿姆斯特丹"];
    [cell setStarLevel: 3];
    [cell.collectionNumberLabel setText: @"510"];
    return cell;
}

- (CGFloat)XZJ_EGOTableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return CELL_HEIGHT;
}

- (UIView *)XZJ_EGOTableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *view = [[UIView alloc] init];
    [view setBackgroundColor: [UIColor clearColor]];
    return view;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
