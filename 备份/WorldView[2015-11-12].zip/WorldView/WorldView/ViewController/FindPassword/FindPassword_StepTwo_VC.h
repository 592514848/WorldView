//
//  FindPassword_StepTwo_VC.h
//  WorldView
//
//  Created by XZJ on 10/29/15.
//  Copyright © 2015 XZJ. All rights reserved.
//

#import "BaseViewController.h"

@interface FindPassword_StepTwo_VC : BaseViewController<UITextFieldDelegate>
{
    UITextField *responserTextFiled;
}
@end
