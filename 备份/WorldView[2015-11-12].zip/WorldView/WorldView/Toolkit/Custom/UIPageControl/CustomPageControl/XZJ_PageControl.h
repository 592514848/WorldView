//
//  XZJ_PageControl_One.h
//  GRDApplication
//
//  Created by 6602 on 14-3-31.
//  Copyright (c) 2014年 Xiong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XZJ_PageControl : UIPageControl
@property(nonatomic, retain) UIColor *activeColor;
@property(nonatomic, retain) UIColor *inactiveColor;
@end
