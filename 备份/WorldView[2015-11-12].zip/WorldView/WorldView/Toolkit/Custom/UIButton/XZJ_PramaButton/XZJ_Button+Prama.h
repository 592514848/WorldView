//
//  XZJ_Button+Prama_One.h
//  GRDApplication
//
//  Created by 6602 on 13-12-29.
//  Copyright (c) 2013年 Xiong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XZJ_Button_Prama : UIButton
@property(retain,nonatomic) NSDictionary * pramaDictionary;
@property(retain,nonatomic) NSIndexPath *indexPath;
@end
