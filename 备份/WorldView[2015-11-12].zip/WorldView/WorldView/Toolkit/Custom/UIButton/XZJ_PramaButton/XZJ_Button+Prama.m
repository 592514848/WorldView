//
//  XZJ_Button+Prama_One.m
//  GRDApplication
//
//  Created by 6602 on 13-12-29.
//  Copyright (c) 2013年 Xiong. All rights reserved.
//

#import "XZJ_Button+Prama.h"

@implementation XZJ_Button_Prama
@synthesize pramaDictionary;
@synthesize indexPath;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
    }
    return self;
}
@end
