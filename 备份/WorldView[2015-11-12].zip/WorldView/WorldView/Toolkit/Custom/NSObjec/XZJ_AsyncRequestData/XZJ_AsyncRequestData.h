//
//  XZJ_AsyncRequestData.h
//  XZJ_GetAsyncData
//
//  Created by 6602 on 13-12-9.
//  Copyright (c) 2013年 Xiong. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "XZJ_ApplicationClass.h"

@protocol XZJ_AsyncRequestDataDelegate;
@interface XZJ_AsyncRequestData : NSObject <NSURLConnectionDataDelegate>

/*!
 @property delegate
 @abstract 委托对象
 */
@property(nonatomic) id<XZJ_AsyncRequestDataDelegate> delegate;
- (id)initWithDelegate:(id<XZJ_AsyncRequestDataDelegate>) _delegate;
- (void)startAsyncRequestData_GET:(NSString *) _requestURL showIndicator:(BOOL) isShow;
- (void)startAsyncRequestData_GET:(NSString *) _requestURL showIndicator:(BOOL) isShow isTip:(BOOL) isTip;
- (void)startAsyncRequestData_GET:(NSString *) _requestURL showIndicator:(BOOL) isShow isOuter:(BOOL) isOuter;
- (void)startAsyncRequestData_GET:(NSString *) _requestURL contentType:(NSString *) _contentType showIndicator:(BOOL) isShow isTip:(BOOL) isTip isOuter:(BOOL) isOuter;
- (void)startAsyncRequestData_POST:(NSString *) _requestURL param:(NSString *) _param showIndicator:(BOOL) isShow;
- (void)startAsyncUploadImageWithURL:(NSString *) _requestURL imageData:(NSData *) imageData showIndicator:(BOOL) isShow;
- (NSDictionary *)startSyncRequestData_POST:(NSString *) _requestURL param:(NSString *) _param showIndicator:(BOOL) isShow;
- (NSDictionary *)startSyncRequestData_GET:(NSString *) _requestURL showIndicator:(BOOL) isShow;
@end

@protocol XZJ_AsyncRequestDataDelegate <NSObject>
@optional
- (void)XZJ_AsyncRequestDataReceiveData:(NSDictionary *) responseDictionary;
- (void)XZJ_AsyncRequestDataUploadFinished:(BOOL) responseResult;
@end
